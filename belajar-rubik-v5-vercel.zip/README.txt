Belajar Rubik
=============
Buka index.html di browser. Tidak perlu server atau instalasi.

Struktur folder
- index.html          : kerangka halaman (memuat semua skrip di bawah)
- style.css           : tampilan, mode terang/gelap otomatis
- js/solver.js        : model kubus 3x3 dan solver dua fase (sekitar 20 gerakan)
- js/materi.js        : isi materi dasar (notasi, Solver 3D, Magic, latihan, tips)
- js/metode.js        : materi lengkap semua metode: Pemula, CFOP, Roux, ZZ, Petrus
- js/kasus.js         : data kasus (Cross 23, F2L 41, OLL 57, PLL 21, CMLL 42), DIBUAT OTOMATIS
- js/deteksi.js       : deteksi kesalahan isian kubus, notasi rumus, dan hasil solver
- js/app.js           : tampilan, timer, Solver 3D, dan fitur Magic
- seni/seni.js        : kode seni (ikon kubus, gambar arah putaran, penamaan berkas gambar)
- seni/gambar/        : semua file gambar (ikon, logo, gerakan, tahap metode, kasus)
- seni/gambar/kasus/  : gambar tiap kasus (cross, f2l, oll, pll, cmll) dalam SVG dan PNG
- seni/gambar/tahap/  : bentuk kubus setelah tiap tahap metode, SVG dan PNG
- alat/               : skrip pembuat gambar dan data (node, tidak dibutuhkan untuk membuka situs)
- seni/gambar/index.html : galeri semua gambar
- seni/gambar/DAFTAR-GAMBAR.txt : daftar nama file dan artinya

Fitur belajar dan latihan
- Tiap rumus punya baris "Mulai dari": cara memegang kubus dan posisi pola sebelum rumus dimulai.
  Kartu kasus (Cross, F2L, OLL, PLL, CMLL) menjelaskan cara membaca gambar dan arah menghadapnya.
- Acak & timer: acakan, semua waktu, dan statistik (terbaik, rata-rata 5, rata-rata 12) tersimpan di
  perangkat (localStorage). Ada +2, DNF, hapus per waktu, hapus semua, dan salin riwayat.
- Sulap Cube (Magic): mode Jelajah (26 urutan gerakan berulang, dikelompokkan Easy, Normal, Hard menurut
  total gerakan) dan mode Tantangan sulap (3 fase):
    Easy   4 gerakan, daftar langkah selalu terlihat
    Normal 8 gerakan (termasuk 180 derajat), daftar disembunyikan, boleh mengintip 3 kali
    Hard   14 gerakan (termasuk lapisan tengah M, E, S), pertunjukan cepat, boleh mengintip 2 kali
  Cara main: lihat pertunjukan sulap, lalu kembalikan kubus dengan tombol gerakan atau papan ketik
  (huruf, Shift untuk prime). Ada Undo, Petunjuk, Intip, Ulangi level, bintang 1 sampai 3, skor dengan
  bonus waktu dan penalti, dan rekor per fase yang tersimpan.

Isi metode (menu Metode)
- Mengenal kubus, Perbandingan metode.
- Layer demi layer: 8 langkah lengkap dengan gambar bentuk kubus tiap langkah.
- CFOP: Pengantar, Cross (23 kasus satu edge), F2L (41 kasus), OLL (2-look dan 57 kasus),
  PLL (2-look dan 21 kasus).
- Roux: Pengantar, dua blok, CMLL (42 kasus), LSE.
- ZZ (EOLine, F2L tanpa rotasi, OCLL, PLL) dan Petrus (blok 2x2x2, 2x2x3, EO, F2L).
- Setiap kasus punya gambar, rumus, tombol Salin, dan tombol Peragakan. Peragakan memulai
  kubus 3D dari posisi kasus itu lalu memainkan rumusnya.

Cara rumus diperiksa
- OLL (57) dan PLL (21): diuji dengan model kubus. Semua unik, tidak merusak dua lapisan
  pertama, dan benar-benar mengorientasikan atau mempermutasi lapisan terakhir.
- F2L (41), Cross (23), dan CMLL (42): dicari komputer sebagai gerakan terpendek lalu diuji,
  jadi dijamin benar tapi bisa berbeda dari rumus populer.
- Langkah 5 sampai 7 metode pemula disimulasikan: aturannya selalu berhasil dalam paling
  banyak dua sampai tiga kali rumus.

Membangun ulang gambar dan data
- node alat/bangun-kasus.js   : membuat seni/gambar/kasus, seni/gambar/tahap, dan js/kasus.js
- node alat/bangun-ikon.js    : membuat ikon SVG bab
- python3 alat/svg-ke-png.py [folder ...] : mengubah SVG menjadi PNG (butuh Playwright)
- node alat/bangun-galeri.js  : memperbarui galeri gambar dan daftar gambar

Deteksi kesalahan
- Solver 3D memeriksa isian sebelum menghitung: kotak kosong, jumlah warna, pusat sisi,
  sudut/rusuk yang tidak mungkin, sudut terpuntir, rusuk terbalik, dan paritas.
  Setiap masalah ditampilkan dengan tombol Tunjukkan yang membuka sisi terkait dan
  menyorot stikernya.
- Coba rumus memeriksa notasi (kurung, gerakan tidak dikenal, gerakan yang menempel)
  dan memberi saran perbaikan.
- Hasil solver diperiksa ulang oleh kubus sebelum ditampilkan.
- Jika rumus di Coba rumus mengubah posisi kubus, langkah lama dihapus dan kamu bisa
  menghitung ulang dari posisi sekarang.

Catatan
- Font diambil dari Google Fonts (perlu internet). Tanpa internet tampilan tetap jalan
  memakai font bawaan perangkat.
- Jangan pindahkan folder seni/ dari index.html, karena situs memuatnya dengan alamat relatif.

Akun (masuk & daftar)
- Menu samping menampilkan status akun. Halaman: Daftar (#daftar), Masuk (#masuk), Akun (#akun).
- Kata sandi diperiksa di server (api/*.js) dan disimpan sebagai hash scrypt dengan garam acak.
- IP saat daftar disimpan (rip) dan IP masuk terakhir (lip) di data akun.
- Kunci akun: salah kata sandi 5 kali -> akun dikunci 30 menit. Setelah kunci habis, satu kali salah lagi -> akun dikunci permanen.
- Batas per IP: 20 kali gagal dalam 30 menit -> IP ditahan 30 menit (mencegah tebak sandi lintas akun).
- Penyimpanan akun: Upstash Redis lewat Vercel. Butuh variabel KV_REST_API_URL dan KV_REST_API_TOKEN.
- Perlu dijalankan di Vercel (atau 'vercel dev'). Membuka index.html langsung dari file tidak bisa memakai akun.
- Riwayat belajar (timer, materi, sulap) masih disimpan di browser per akun, belum tersinkron antar perangkat.

Membuka kunci akun secara manual
- Hapus key "sec:<nama>" di Upstash (Data Browser). Itu menghapus kunci dan hitungan gagal akun tersebut.
