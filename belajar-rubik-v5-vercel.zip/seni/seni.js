/* Seni: ikon kubus, gambar arah putaran, dan penamaan berkas gambar.
   Semua gambar disimpan di folder seni/gambar/. Berkas ini hanya merangkai gambar itu. */
const ART_DIR='seni/gambar/';
/* ===== Ikon kubus mini & seni arah putaran ===== */
const IC={y:'#ffd500',w:'#f4f4f4',r:'#c8102e',o:'#ff5800',b:'#0051ba',g:'#009a44',n:'#c3cad6'};
const IV={beranda:['YYYYYYYYY','GGGGGGGGG','RRRRRRRRR'],notasi:['YBYRYOYGY','OGBRRWGBO','BRGOOYRGB'],pemula:['NYNYYYNYN','NNNGGGGGG','NNNRRRRRR'],cfop:['NYNYYYNYN','NNNNNNGGG','NNNNNNRRR'],cross:['NWNWWWNWN','NNNNNNNNN','NNNNNNNNN'],f2l:['NNNNNNNNN','NNNGGGGGG','NNNRRRRRR'],oll:['YYYYYYYYY','GNGNNNNNN','RNRNNNNNN'],pll:['YYYYYYYYY','GRGGGGGGG','RGRRRRRRR'],solver:['RWBYGOWYR','GOYWBRGOW','BYRORBWGY'],magic:['YWYWYWYWY','GBGBGBGBG','ROROROROR'],latihan:['WNWNWNWNW','NNNNNNNNN','NNNNNNNNN'],tips:['YYYYYYYYY','WWWWWWWWW','BBBBBBBBB'],kubus:['YNYNNNYNY','GNGNNNGNG','RNRNNNRNR'],metode:['ROYGBWROY','YGBROWGYB','WOYBRGOWY'],roux:['NNNNNNNNN','NNNGNGGNG','NNNRRRRRR'],'roux-blok':['NNNNNNNNN','NNNGNNGNN','NNNNNNNNN'],cmll:['YNYNNNYNY','GNGNNNNNN','RNRNNNNNN'],lse:['NYNYYYNYN','NGNNNNNGN','NNNNNNNNN'],zz:['NNNNNNNNN','NNNNNNNGN','NNNNNNNRN'],petrus:['NNNNNNNNN','NNNNNNGGN','NNNNNNNNR']};
const svgW=(px,g)=>`<svg viewBox="0 0 100 100" width="${px}" height="${px}" aria-hidden="true">${g}</svg>`;
function miniCube(T,L,R,px){const face=(s,p0,u,v)=>[...s].map((ch,i)=>{const c=i%3,r=(i/3)|0,pt=(x,y)=>[p0[0]+u[0]*x+v[0]*y,p0[1]+u[1]*x+v[1]*y].map(n=>n.toFixed(1)).join(',');
 return `<polygon points="${pt(c,r)} ${pt(c+1,r)} ${pt(c+1,r+1)} ${pt(c,r+1)}" fill="${IC[ch.toLowerCase()]}" stroke="#0b0b0b" stroke-width="1.3" stroke-linejoin="round"/>`}).join('');
 return svgW(px,face(L,[14,32],[12,6],[0,14])+face(R,[50,50],[12,-6],[0,14])+face(T,[50,14],[12,6],[-12,6]))}
const icoSvg=(id,px)=>{const v=IV[id]||IV.beranda;return miniCube(v[0],v[1],v[2],px)};
const ico=(id,px)=>`<img class="gi" src="${ART_DIR}ikon/ikon_${IV[id]?id:'beranda'}.png" width="${px}" height="${px}" alt="">`;
const VS={U:[1,'t'],F:[1,'l'],R:[1,'r'],D:[2,'t'],L:[2,'l'],B:[2,'r']},FMX={t:[12,6,-12,6,50,14],l:[12,6,0,14,14,32],r:[12,-6,0,14,50,50]},LB=[{t:'U',l:'F',r:'R'},{t:'D',l:'L',r:'B'}];

/* ===== Gambar arah putaran untuk semua notasi (M E S, r l u d f b, x y z) ===== */
const PJ=(x,y,z)=>[50+12*x-12*z,53+6*x-14*y+6*z];
const FACE3={U:{k:'t',n:[0,1,0],cell:(c,r)=>[c-1,1.5,r-1]},F:{k:'l',n:[0,0,1],cell:(c,r)=>[c-1,1-r,1.5]},R:{k:'r',n:[1,0,0],cell:(c,r)=>[1.5,1-r,1-c]}};
const AR={U:[['U','a']],F:[['F','a']],R:[['R','a']],D:[['F','s'],['R','s']],L:[['F','s'],['U','s']],B:[['U','s'],['R','s']],M:[['F','s'],['U','s']],E:[['F','s'],['R','s']],S:[['U','s'],['R','s']],r:[['R','a'],['F','s']],l:[['F','s'],['U','s']],u:[['U','a'],['F','s']],d:[['F','s'],['R','s']],f:[['F','a'],['U','s']],b:[['U','s'],['R','s']],x:[['R','a'],['F','s']],y:[['U','a'],['F','s']],z:[['F','a'],['U','s']]};
const rotp=(p,ax,deg)=>{const a=deg*Math.PI/180,c=Math.cos(a),s=Math.sin(a),[x,y,z]=p;return ax===0?[x,y*c-z*s,y*s+z*c]:ax===1?[x*c+z*s,y,-x*s+z*c]:[x*c-y*s,x*s+y*c,z]};
const crs=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
function art3d(n,k,px){const[ax,ls,ph]=MD[n],al=ph*90*k,sg=al<0?-1:1,w=[0,0,0];w[ax]=sg;let g='';const hl={U:[],F:[],R:[]};
 for(const f of 'UFR'){const F3=FACE3[f];g+=`<g transform="matrix(${FMX[F3.k].join(' ')})">`;
  for(let r=0;r<3;r++)for(let c=0;c<3;c++){const p=F3.cell(c,r),cb=p.map((v,i)=>F3.n[i]?F3.n[i]:Math.round(v)),on=ls.includes(cb[ax]);if(on)hl[f].push(p);
   g+=`<rect x="${c}" y="${r}" width="1" height="1" fill="${on?'#ffd500':'#d9dee8'}" stroke="#0b0b0b" stroke-width=".13" stroke-linejoin="round"/>`}
  g+=`<text x="1.5" y="1.95" font-size="1.1" text-anchor="middle" fill="#0b0b0b" opacity=".4">${f}</text></g>`}
 for(const[f,t]of AR[n]){const F3=FACE3[f],h=hl[f];if(!h.length)continue;let pts;
  if(t==='s'){const m=[0,1,2].map(i=>F3.n[i]?F3.n[i]*1.58:h.reduce((a,p)=>a+p[i],0)/h.length),d=crs(w,m),L=Math.hypot(...d)||1;pts=[-.95,.95].map(s=>m.map((v,i)=>v+d[i]/L*s))}
  else{const ei=F3.n.findIndex(v=>!v),base=F3.n.map((v,i)=>v?v*1.58:(i===ei?.9:0));pts=[];for(let j=0;j<=14;j++)pts.push(rotp(base,ax,sg*(-120+240*j/14)))}
  const P=pts.map(p=>PJ(...p)),d=P.map(p=>p.map(f1).join(',')).join(' '),E=P[P.length-1],B=P[P.length-2],dx=E[0]-B[0],dy=E[1]-B[1],dl=Math.hypot(dx,dy)||1,ux=dx/dl,uy=dy/dl,nx=-uy,ny=ux,hd=[[E[0]+ux*3.4,E[1]+uy*3.4],[E[0]-ux*2.4+nx*3.6,E[1]-uy*2.4+ny*3.6],[E[0]-ux*2.4-nx*3.6,E[1]-uy*2.4-ny*3.6]].map(p=>p.map(f1).join(',')).join(' ');
  g+=`<polyline points="${d}" fill="none" stroke="#fff" stroke-width="5.6" stroke-linecap="round" stroke-linejoin="round"/><polyline points="${d}" fill="none" stroke="#c8102e" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/><polygon points="${hd}" fill="#c8102e" stroke="#fff" stroke-width="1" stroke-linejoin="round"/>`}
 if(k===2)g+='<text x="3" y="12" font-size="12" font-weight="700" fill="#c8102e">×2</text>';
 const HN={D:'sisi bawah',L:'sisi kiri',B:'sisi belakang'};if(HN[n])g+=`<text x="50" y="98" font-size="9" font-weight="700" text-anchor="middle" fill="#c8102e">${HN[n]}</text>`;
 return svgW(px,g)}
const f1=n=>n.toFixed(1);

const FNM={U:'Atas',D:'Bawah',R:'Kanan',L:'Kiri',F:'Depan',B:'Belakang'};

const DN={M:'lapisan tengah kiri-kanan (arahnya seperti L)',E:'lapisan tengah atas-bawah (arahnya seperti D)',S:'lapisan tengah depan-belakang (arahnya seperti F)',x:'seluruh kubus (searah R)',y:'seluruh kubus (searah U)',z:'seluruh kubus (searah F)'},WF={r:'Kanan',l:'Kiri',u:'Atas',d:'Bawah',f:'Depan',b:'Belakang'};

const gfile=(n,k)=>{const sfx=k===2?'2':k<0?'-prime':'',dir=k===2?'putar-180':k>0?'searah-jarum-jam':'berlawanan-jarum-jam';let kind,part;
 if(FNM[n]){kind='sisi';part=FNM[n].toLowerCase()}else if('MES'.includes(n)){kind='lapisan-tengah';part={M:'kiri-kanan',E:'atas-bawah',S:'depan-belakang'}[n]}else if('xyz'.includes(n)){kind='putar-seluruh-kubus';part={x:'searah-R',y:'searah-U',z:'searah-F'}[n]}else{kind='dua-lapis';part=WF[n].toLowerCase()}
 return `${kind}_${kind==='dua-lapis'?'wide-':''}${n}${sfx}_${part}_${dir}.png`};
const moveSvg=(t,px)=>{const q=tok(t);return q?art3d(q.n,q.k,px):''};
function moveArt(t,px){const q=tok(t);if(!q)return '';return `<img class="gm" src="${ART_DIR}gerakan/${gfile(q.n,q.k)}" width="${px}" height="${px}" alt="${fm(t)}: ${fm(desc(t))}" loading="lazy">`}
