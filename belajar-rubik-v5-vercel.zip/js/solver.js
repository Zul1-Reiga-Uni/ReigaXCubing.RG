/* Model kubus 3x3 + solver dua fase (hasil sekitar 20-25 gerakan) */
const FN={U:[0,1,0],R:[1,0,0],F:[0,0,1],D:[0,-1,0],L:[-1,0,0],B:[0,0,-1]},FO=['U','R','F','D','L','B'];
const SL=[],IX={},CI={},CU=new Map();
FO.forEach(f=>{const n=FN[f],ax=n.findIndex(v=>v),o=[0,1,2].filter(k=>k!==ax);
for(let i=-1;i<2;i++)for(let j=-1;j<2;j++){const c=[0,0,0];c[ax]=n[ax];c[o[0]]=i;c[o[1]]=j;const id=SL.length;
SL.push({c,n,f});IX[c.join()+'|'+n.join()]=id;if(!i&&!j)CI[f]=id;const k=c.join();if(!CU.has(k))CU.set(k,[]);CU.get(k).push(id)}});
function rot(v,ax,ph){let[x,y,z]=v;for(let t=0;t<(ph>0?1:3);t++)[x,y,z]=ax==0?[x,-z,y]:ax==1?[z,y,-x]:[-y,x,z];return[x,y,z]}
const A3=[-1,0,1];
const MD={R:[0,[1],-1],L:[0,[-1],1],U:[1,[1],-1],D:[1,[-1],1],F:[2,[1],-1],B:[2,[-1],1],M:[0,[0],1],E:[1,[0],1],S:[2,[0],-1],
x:[0,A3,-1],y:[1,A3,-1],z:[2,A3,-1],r:[0,[0,1],-1],l:[0,[-1,0],1],u:[1,[0,1],-1],d:[1,[-1,0],1],f:[2,[0,1],-1],b:[2,[-1,0],1]};
const QP={};
for(const m in MD){const[ax,ls,ph]=MD[m];QP[m]=SL.map((s,i)=>ls.includes(s.c[ax])?IX[rot(s.c,ax,ph).join()+'|'+rot(s.n,ax,ph).join()]:i)}
const ID=SL.map((_,i)=>i),cp=(a,b)=>a.map(v=>b[v]),ap=(s,p)=>{const o=s.slice();p.forEach((j,i)=>o[j]=s[i]);return o};
function tok(t){const m=/^([RLUDFB]w|[RLUDFBMESxyzrludfb])(i|'|’|2)?(')?$/.exec(t);if(!m)return null;let n=m[1];if(n[1]==='w')n=n[0].toLowerCase();
return{n,k:m[2]==='2'?2:(m[2]||m[3])?-1:1}}
const TP=(n,k)=>{let p=ID;for(let i=0;i<(k<0?3:k);i++)p=cp(p,QP[n]);return p};
const seqP=str=>str.trim().split(/\s+/).reduce((p,t)=>{const q=tok(t);return cp(p,TP(q.n,q.k))},ID);

/* ===== Solver dua fase (gaya Kociemba): hasil sekitar 20-25 gerakan ===== */
const cubs=[...CU.values()],detv=(u,v,w)=>u[0]*(v[1]*w[2]-v[2]*w[1])-u[1]*(v[0]*w[2]-v[2]*w[0])+u[2]*(v[0]*w[1]-v[1]*w[0]);
const CORN=[],EDGE=[],SI=[];
cubs.filter(l=>l.length===3).forEach(l=>{const y=l.find(i=>SL[i].n[1]!==0),o=l.filter(i=>i!==y),x=o.find(i=>SL[i].n[0]!==0),z=o.find(i=>SL[i].n[2]!==0);CORN.push(detv(SL[y].n,SL[x].n,SL[z].n)>0?[y,x,z]:[y,z,x])});
cubs.filter(l=>l.length===2).forEach(l=>{let p=l.find(i=>SL[i].n[1]!==0);if(p===undefined)p=l.find(i=>SL[i].n[2]!==0);EDGE.push([p,l.find(i=>i!==p)])});
EDGE.sort((a,b)=>(SL[a[0]].c[1]===0)-(SL[b[0]].c[1]===0));
CORN.forEach((l,p)=>l.forEach((i,k)=>SI[i]=[p,k]));EDGE.forEach((l,p)=>l.forEach((i,k)=>SI[i]=[p,k]));
const MN=[],MP=[];for(const X of 'URFDLB'){MN.push(X,X+'2',X+"'");MP.push(TP(X,1),TP(X,2),TP(X,-1))}
const mkM=(L,P)=>L.map(l=>{const d=l.map(i=>SI[P[i]]);return{p:d[0][0],d:d.map(x=>x[1])}});
const CMV=MP.map(P=>mkM(CORN,P)),EMV=MP.map(P=>mkM(EDGE,P));
function applyC(c,m){const cp=[],co=[],ep=[],eo=[];CMV[m].forEach((x,q)=>{cp[x.p]=c.cp[q];co[x.p]=x.d[c.co[q]]});EMV[m].forEach((x,q)=>{ep[x.p]=c.ep[q];eo[x.p]=x.d[c.eo[q]]});return{cp,co,ep,eo}}
function toCub(s){const cc=i=>s[CI[SL[i].f]],find=(L,p)=>{const cols=L[p].map(i=>s[i]);for(let h=0;h<L.length;h++){const hc=L[h].map(cc);if(hc.every(c=>cols.includes(c))&&cols.every(c=>hc.includes(c)))return[h,cols.indexOf(cc(L[h][0]))]}return null};
 const r={cp:[],co:[],ep:[],eo:[]};for(let p=0;p<8;p++){const f=find(CORN,p);if(!f)return null;r.cp.push(f[0]);r.co.push(f[1])}
 for(let p=0;p<12;p++){const f=find(EDGE,p);if(!f)return null;r.ep.push(f[0]);r.eo.push(f[1])}
 if(new Set(r.cp).size<8||new Set(r.ep).size<12)return null;return r}
const tw=co=>{let r=0;for(let i=0;i<7;i++)r=r*3+co[i];return r},untw=r=>{const co=[];let s=0;for(let i=6;i>=0;i--){co[i]=r%3;s+=co[i];r=(r-co[i])/3}co[7]=(3-s%3)%3;return co};
const fl=eo=>{let r=0;for(let i=0;i<11;i++)r=r*2+eo[i];return r},unfl=r=>{const eo=[];let s=0;for(let i=10;i>=0;i--){eo[i]=r&1;s+=eo[i];r>>=1}eo[11]=s%2;return eo};
const FACT=[1,1,2,6,24,120,720,5040],rank=(p,n)=>{let r=0;for(let i=0;i<n-1;i++){let c=0;for(let j=i+1;j<n;j++)if(p[j]<p[i])c++;r+=c*FACT[n-1-i]}return r};
const unrank=(r,n)=>{const p=[],av=[...Array(n).keys()];for(let i=0;i<n;i++){const f=FACT[n-1-i],q=Math.floor(r/f);r%=f;p.push(av.splice(q,1)[0])}return p};
const par=a=>{let c=0;for(let i=0;i<a.length;i++)for(let j=i+1;j<a.length;j++)if(a[j]<a[i])c++;return c%2};
const MK=[],MI=new Int16Array(4096).fill(-1);for(let m=0;m<4096;m++){let b=0;for(let i=0;i<12;i++)b+=m>>i&1;if(b===4){MI[m]=MK.length;MK.push(m)}}
const GM=MI[0xF00],M2=[0,1,2,9,10,11,4,13,7,16];
let T1,F1,S1,P1a,P1b,CP2,EP2,SL2,P2a,P2b,READY=false;
function bfsT(size,mv,A,B,nB,goal){const D=new Uint8Array(size).fill(255);D[goal]=0;let fr=[goal],d=0;while(fr.length){const nx=[];for(const v of fr){const a=(v/nB)|0,b=v%nB;for(let m=0;m<mv;m++){const w=A[a*mv+m]*nB+B[b*mv+m];if(D[w]===255){D[w]=d+1;nx.push(w)}}}fr=nx;d++}return D}
const PST=[
()=>{T1=new Int16Array(2187*18);for(let r=0;r<2187;r++){const co=untw(r);for(let m=0;m<18;m++){const n=[];CMV[m].forEach((x,q)=>n[x.p]=x.d[co[q]]);T1[r*18+m]=tw(n)}}},
()=>{F1=new Int16Array(2048*18);for(let r=0;r<2048;r++){const eo=unfl(r);for(let m=0;m<18;m++){const n=[];EMV[m].forEach((x,q)=>n[x.p]=x.d[eo[q]]);F1[r*18+m]=fl(n)}}},
()=>{S1=new Int16Array(495*18);MK.forEach((k,i)=>{for(let m=0;m<18;m++){let n=0;EMV[m].forEach((x,q)=>{if(k>>q&1)n|=1<<x.p});S1[i*18+m]=MI[n]}});},
()=>{CP2=new Uint16Array(40320*10);EP2=new Uint16Array(40320*10);SL2=new Uint8Array(24*10);},
()=>{for(let r=0;r<40320;r++){const p=unrank(r,8);M2.forEach((m,j)=>{const a=[],b=[];CMV[m].forEach((x,q)=>a[x.p]=p[q]);EMV[m].forEach((x,q)=>{if(q<8)b[x.p]=p[q]});CP2[r*10+j]=rank(a,8);EP2[r*10+j]=rank(b,8)})}},
()=>{for(let r=0;r<24;r++){const p=unrank(r,4);M2.forEach((m,j)=>{const a=[];EMV[m].forEach((x,q)=>{if(q>=8)a[x.p-8]=p[q-8]});SL2[r*10+j]=rank(a,4)})}},
()=>{P1a=bfsT(2187*495,18,T1,S1,495,GM)},
()=>{P1b=bfsT(2048*495,18,F1,S1,495,GM)},
()=>{P2a=bfsT(40320*24,10,CP2,SL2,24,0)},
()=>{P2b=bfsT(40320*24,10,EP2,SL2,24,0)},
];
let PI=0,PP=null;
function prep(){while(PI<PST.length)PST[PI++]();READY=true}
function prepAsync(){if(READY)return Promise.resolve();if(PP)return PP;return PP=new Promise(res=>{const nx=()=>{if(PI<PST.length){PST[PI++]();setTimeout(nx,0)}else{READY=true;res()}};setTimeout(nx,0)})}
const skip=(fc,last)=>fc===last||(last>=0&&(fc+3)%6===last&&fc<last);
function solveC(c0,dead,mt0,esc){let maxT=mt0,found=null;const t0=tw(c0.co),f0=fl(c0.eo);let mk=0;c0.ep.forEach((e,p)=>{if(e>=8)mk|=1<<p});const s0=MI[mk];
 const d2=(c,e,s,g,L,last,out)=>{const h=Math.max(P2a[c*24+s],P2b[e*24+s]);if(g+h>L)return false;if(h===0)return true;if(g===L)return false;
  for(let j=0;j<10;j++){const fc=(M2[j]/3)|0;if(skip(fc,last))continue;out.push(j);if(d2(CP2[c*10+j],EP2[e*10+j],SL2[s*10+j],g+1,L,fc,out))return true;out.pop()}return false};
 for(let pass=0;pass<(esc?2:1)&&!found;pass++){
  for(let L1=0;L1<=13&&!found;L1++){const path=[];
   const d1=(t,f,s,g,last)=>{if(Date.now()>dead)return false;const h=Math.max(P1a[t*495+s],P1b[f*495+s]);if(g+h>L1)return false;
    if(g===L1){if(h!==0)return false;let c=c0;path.forEach(m=>c=applyC(c,m));const cp=rank(c.cp,8),ep=rank(c.ep.slice(0,8),8),sp=rank(c.ep.slice(8).map(v=>v-8),4);
     for(let L2=0;L2<=maxT-path.length;L2++){const o=[];if(d2(cp,ep,sp,0,L2,-1,o)){found=path.concat(o.map(j=>M2[j]));return true}}return false}
    for(let m=0;m<18;m++){const fc=(m/3)|0;if(skip(fc,last))continue;path.push(m);if(d1(T1[t*18+m],F1[f*18+m],S1[s*18+m],g+1,fc))return true;path.pop()}return false};
   d1(t0,f0,s0,0,-1)}
  maxT=45}
 return found}
let solveWhy='';
function solve(s){solveWhy='';const c=toCub(s);if(!c){solveWhy='piece';return null}
 if(c.co.reduce((a,b)=>a+b)%3){solveWhy='twist';return null}if(c.eo.reduce((a,b)=>a+b)%2){solveWhy='flip';return null}if(par(c.cp)!==par(c.ep)){solveWhy='parity';return null}
 prep();let r=solveC(c,Date.now()+12000,30,true);if(!r){solveWhy='fail';return null}
 const t1=Date.now()+300;while(r.length>14&&Date.now()<t1){const b=solveC(c,t1,r.length-1,false);if(!b)break;r=b}return r.map(m=>MN[m])}
