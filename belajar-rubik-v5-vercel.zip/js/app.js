/* Tampilan: materi, notasi, timer, dan Solver 3D */
const $=s=>document.querySelector(s),fm=t=>t.replace(/'/g,"’");
const LOGO='<img class="lg" src="seni/gambar/logo/logo-belajar-rubik.png" width="30" height="30" alt="">';
const groups=[...new Set(L.map(l=>l.g))];
let done={},cur='';
const loadDone=()=>{try{done=JSON.parse(localStorage.getItem(ukey('rubik-done'))||'{}')}catch(e){done={}}};loadDone();
const save=()=>{try{localStorage.setItem(ukey('rubik-done'),JSON.stringify(done))}catch(e){}};
document.querySelectorAll('[data-st]').forEach(e=>{e.innerHTML=LOGO});
function nav(){
 $('#nv').innerHTML=`<div class="nvh"><a class="logo" href="#beranda"><span class="st" data-st></span>Belajar Rubik</a><button class="btn mbtn nx" id="nvx" type="button" aria-label="Tutup menu">✕ Tutup</button></div>`+akunBox()+
 groups.map(g=>`<h3>${g}</h3>`+L.filter(l=>l.g===g).map(l=>`<a href="#${l.id}" class="nvi ${l.id===cur?'on':''}" style="--c:${C[l.c]}"><span class="ic">${ico(l.id,38)}</span><span class="tt">${l.t}</span>${done[l.id]?'<span class="ok">✓</span>':''}</a>`).join('')).join('');
 document.querySelectorAll('[data-st]').forEach(e=>{e.innerHTML=LOGO});
}
/* ===== Timer dengan riwayat tersimpan (localStorage) ===== */
const TKEY='rubik-timer';let TS={sc:'',list:[]},t0=0,raf=0,run=false;
const loadT=()=>{TS={sc:'',list:[]};try{const o=JSON.parse(localStorage.getItem(ukey(TKEY))||'null');if(o&&Array.isArray(o.list))TS={sc:o.sc||'',list:o.list.slice(0,200)}}catch(e){}};
const saveT=()=>{try{localStorage.setItem(ukey(TKEY),JSON.stringify(TS))}catch(e){}};
const tval=e=>e.p==='dnf'?Infinity:e.t+(e.p===2?2000:0);
const tfmt=e=>e.p==='dnf'?'DNF':((e.t+(e.p===2?2000:0))/1000).toFixed(2)+(e.p===2?'+':'');
const sec2=v=>isFinite(v)?(v/1000).toFixed(2):'DNF';
function avgN(n){if(TS.list.length<n)return '-';const a=TS.list.slice(0,n).map(tval).sort((x,y)=>x-y);if(a.filter(v=>v===Infinity).length>1)return 'DNF';const m=a.slice(1,-1);const s=m.reduce((p,q)=>p+q,0)/m.length;return sec2(s)}
function scramble(){
 const f=['U','D','R','L','F','B'],ax={U:0,D:0,R:1,L:1,F:2,B:2},m=['',"'",'2'],o=[];let a='',b='';
 while(o.length<20){const x=f[Math.random()*6|0];if(x===a||(b&&ax[x]===ax[a]&&x===b))continue;o.push(x+m[Math.random()*3|0]);b=a;a=x}
 return fm(o.join(' '));
}
/* Timer tetap jalan walau pindah halaman; tampilan hanya diperbarui kalau halaman timer terbuka */
function tick(){const e=$('#tm');if(e)e.textContent=((performance.now()-t0)/1000).toFixed(2);raf=e?requestAnimationFrame(tick):0}
function toggle(){
 if(!$('#tb'))return;
 if(!run){t0=performance.now();run=true;tick();$('#tb').textContent='Berhenti'}
 else{cancelAnimationFrame(raf);run=false;const t=Math.round(performance.now()-t0);$('#tm').textContent=(t/1000).toFixed(2);
  TS.list.unshift({t,sc:TS.sc,d:Date.now(),p:0});TS.list=TS.list.slice(0,200);TS.sc=scramble();saveT();
  $('#tb').textContent='Mulai';$('#sc').textContent=TS.sc;tStats()}
}
function rst(){cancelAnimationFrame(raf);run=false;const m=$('#tm'),b=$('#tb');if(m)m.textContent='0.00';if(b)b.textContent='Mulai'}
/* Grafik 30 waktu terakhir (DNF tidak ikut) */
function spark(list){const v=list.slice(0,30).map(tval).filter(isFinite).reverse();if(v.length<2)return '';
 const w=300,h=60,mn=Math.min(...v),mx=Math.max(...v),rg=mx-mn||1;
 const pts=v.map((x,i)=>`${(i/(v.length-1)*w).toFixed(1)},${(h-4-(x-mn)/rg*(h-8)).toFixed(1)}`).join(' ');
 return `<svg class="spk" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" role="img" aria-label="Grafik waktu terakhir"><polyline points="${pts}" fill="none" stroke="var(--acc)" stroke-width="2" vector-effect="non-scaling-stroke"/></svg><small class="spk-l">Grafik 30 waktu terakhir. Makin rendah makin cepat.</small>`}
function tStats(){const box=$('#hs');if(!box)return;const L2=TS.list,fin=L2.map(tval).filter(isFinite),best=fin.length?Math.min(...fin):Infinity,mean=fin.length?fin.reduce((p,q)=>p+q,0)/fin.length:Infinity;
 box.innerHTML=`<div class="tst"><div><small>Terbaik</small><b>${sec2(best)}</b></div><div><small>Rata-rata 5</small><b>${avgN(5)}</b></div><div><small>Rata-rata 12</small><b>${avgN(12)}</b></div><div><small>Rata-rata semua</small><b>${sec2(mean)}</b></div><div><small>Jumlah</small><b>${L2.length}</b></div></div>
 ${spark(L2)}<div class="row" style="justify-content:flex-start;margin:10px 0"><button class="btn alt" id="tx">Salin riwayat</button><button class="btn alt" id="tc">Hapus riwayat</button></div>
 ${L2.length?`<ol class="tl2">${L2.slice(0,50).map((e,i)=>`<li${i===0?' class="new"':''}><div><b>${tfmt(e)}</b><span>${new Date(e.d).toLocaleString('id-ID',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'})}</span><code>${fm(e.sc||'')}</code></div><div class="ta"><button data-i="${i}" data-a="p2" class="${e.p===2?'on':''}">+2</button><button data-i="${i}" data-a="dnf" class="${e.p==='dnf'?'on':''}">DNF</button><button data-i="${i}" data-a="del" aria-label="Hapus waktu ini">✕</button></div></li>`).join('')}</ol>`:'<p style="color:var(--mut)">Belum ada waktu. Tekan Mulai, selesaikan kubusmu, lalu tekan Berhenti.</p>'}`;
 box.querySelectorAll('.ta button').forEach(b=>b.onclick=()=>{const i=+b.dataset.i,a=b.dataset.a,e=TS.list[i];if(!e)return;if(a==='del')TS.list.splice(i,1);else if(a==='p2')e.p=e.p===2?0:2;else e.p=e.p==='dnf'?0:'dnf';saveT();tStats()});
 $('#tc').onclick=()=>{if(confirm('Hapus semua riwayat waktu?')){TS.list=[];saveT();tStats()}};
 $('#tx').onclick=()=>{const t=L2.map((e,i)=>`${L2.length-i}. ${tfmt(e)}  ${e.sc||''}`).join('\n');(navigator.clipboard?navigator.clipboard.writeText(t):Promise.reject()).then(()=>{$('#tx').textContent='Tersalin'},()=>{$('#tx').textContent='Gagal'});setTimeout(()=>{const b=$('#tx');if(b)b.textContent='Salin riwayat'},1200)}}
function tool(){
 return `<h2>Acakan</h2><div class="scr" id="sc"></div>
 <div id="tm">0.00</div><div class="row"><button class="btn" id="tb">Mulai</button><button class="btn alt" id="tr">Reset</button><button class="btn alt" id="ns">🎲 Acakan baru</button></div>
 <h2>Riwayat tersimpan</h2>${riwayatNote()}
 <div id="hs"></div>`;
}
function initTimer(){loadT();if(!TS.sc){TS.sc=scramble();saveT()}$('#sc').textContent=TS.sc;$('#tb').onclick=toggle;$('#ns').onclick=()=>{TS.sc=scramble();saveT();$('#sc').textContent=TS.sc};$('#tr').onclick=rst;tStats();cancelAnimationFrame(raf);if(run){$('#tb').textContent='Berhenti';tick()}}
function render(){
 cur=location.hash.slice(1)||'beranda';
 const l=L.find(x=>x.id===cur);
 haltNow();
 if(AUTH_PAGES.includes(cur)){
  if(cur!=='akun'&&me()){location.replace('#akun');return}
  $('#mv').innerHTML=halamanAuth(cur);nav();setMenu(false);window.scrollTo(0,0);bindAuth(cur);return;
 }
 let h='';
 if(!l){
  cur='beranda';
  h=`<h1>Belajar menyelesaikan Rubik 3×3</h1><p class="lead">Mulai dari Mengenal kubus dan notasi, pilih metode (pemula, CFOP, Roux, ZZ, atau Petrus), lalu pelajari tiap tahapnya lengkap dengan gambar dan rumus. Tiap materi punya rumus yang bisa disalin dan penanda “sudah paham”.</p>
  <div class="grid">${L.map(x=>`<a class="card" href="#${x.id}" style="--c:${C[x.c]}"><span class="ic">${ico(x.id,64)}</span><small>${x.g}${done[x.id]?' · selesai':''}</small><b>${x.t}</b></a>`).join('')}</div>`;
 }else{
  h=`<h1>${l.t}</h1>`+(l.p||[]).map((t,i)=>`<p class="${i?'':'lead'}">${fm(t)}</p>`).join('');
  if(l.x||l.a||(l.blocks&&l.blocks.some(b=>b.t==='algs'||b.t==='cases')))h+=demoUI();
  (l.x||[]).forEach(z=>{h+=`<h2>${z.h}</h2><p>${fm(z.p)}</p>`+ag(z.a,l.c)});
  if(l.blocks)h+=blocksHtml(l.blocks,l.c);
  if(l.s)h+=`<h2>Langkah</h2><ol class="s">${l.s.map(t=>`<li>${fm(t)}</li>`).join('')}</ol>`;
  if(l.a)h+=`<h2>Rumus</h2>`+ag(l.a,l.c);
  if(l.tool===1)h+=tool();if(l.tool===2)h+=solverUI();if(l.tool===3)h+=magicUI();
  if(l.tip)h+=`<div class="tip">${fm(l.tip)}</div>`;
  if(!l.tool)h+=`<label class="done"><input type="checkbox" id="ck" ${done[l.id]?'checked':''}> Sudah paham materi ini</label>`;
 }
 $('#mv').innerHTML=h;nav();
 setMenu(false);
 window.scrollTo(0,0);
 const ck=$('#ck');if(ck)ck.onchange=()=>{done[cur]=ck.checked;save();nav()};
 document.querySelectorAll('.cp').forEach(b=>b.onclick=()=>{
  const t=b.dataset.a;(navigator.clipboard?navigator.clipboard.writeText(t):Promise.reject()).then(()=>{b.textContent='Tersalin'},()=>{b.textContent='Gagal'});
  setTimeout(()=>b.textContent='Salin',1200)});
 document.querySelectorAll('.pl').forEach(b=>b.onclick=()=>demo(b.dataset.a,b.dataset.su));
 if($('#tb'))initTimer();
 if($('#sv')){draw();prepAsync()}if($('#mgv'))initMagic();if($('#dm'))initDemo();bindSp();
}
const setMenu=o=>{$('#nv').classList.toggle('open',o);document.body.classList.toggle('menu-open',o);$('#mn').setAttribute('aria-expanded',o);if(o){const s=$('#nv');s.scrollTop=0}};
$('#mn').onclick=()=>setMenu(!$('#nv').classList.contains('open'));
$('#nv').addEventListener('click',e=>{if(e.target.closest('#nvx'))setMenu(false)});
document.addEventListener('click',e=>{if(document.body.classList.contains('menu-open')&&!e.target.closest('#nv')&&!e.target.closest('#mn'))setMenu(false)});
document.addEventListener('keydown',e=>{if(e.key==='Escape')setMenu(false)});
const spaceOk=e=>e.code==='Space'&&cur==='latihan'&&!/^(INPUT|TEXTAREA)$/.test(e.target.tagName);
document.addEventListener('keydown',e=>{if(spaceOk(e)){e.preventDefault();if(!e.repeat)toggle()}});
document.addEventListener('keyup',e=>{if(spaceOk(e))e.preventDefault()});


const CM={W:'#f4f4f4',Y:'#ffd500',R:'#c8102e',O:'#ff5800',B:'#0051ba',G:'#009a44',N:'#8c95a6'},U0=56;
const NR={'0,1,0':'rotateX(90deg)','0,-1,0':'rotateX(-90deg)','1,0,0':'rotateY(90deg)','-1,0,0':'rotateY(-90deg)','0,0,1':'','0,0,-1':'rotateY(180deg)'};
const BT=i=>{const s=SL[i];return `translate3d(${s.c[0]*U0}px,${-s.c[1]*U0}px,${s.c[2]*U0}px) ${NR[s.n.join()]} translateZ(${U0/2}px)`};
const home=()=>SL.map(s=>'YRGWOB'['URFDLB'.indexOf(s.f)]),CTR=Object.values(CI);
let S=home(),SOL=[],pi=0,busy=false,auto=false,pc='W',rx=-28,ry=-38,moved=false,drag=false,sx=0,sy=0;
let cs=1;const view=()=>{const c=$('#cube');if(c)c.style.transform=`scale(${cs}) rotateX(${rx}deg) rotateY(${ry}deg)`};
const paintAll=()=>document.querySelectorAll('.sk').forEach(e=>{e.style.background=CM[S[e.dataset.i]]});
const msg=t=>{const m=$('#msg');if(m){m.textContent=t;if(t)m.scrollIntoView({block:'nearest',behavior:'smooth'})}};
const FACES=[['F','Depan','Pegang kubus dengan sisi Depan menghadap kamu dan sisi Atas tetap di atas.'],['R','Kanan','Putar kubus sampai sisi Kanan menghadap kamu, sisi Atas tetap di atas.'],['B','Belakang','Putar lagi sampai sisi Belakang menghadap kamu, sisi Atas tetap di atas.'],['L','Kiri','Putar lagi sampai sisi Kiri menghadap kamu, sisi Atas tetap di atas.'],['U','Atas','Kembali ke sisi Depan, lalu miringkan sisi Atas ke arahmu. Sisi Depan ada di bagian bawah.'],['D','Bawah','Kembali ke sisi Depan, lalu miringkan sisi Bawah ke arahmu. Sisi Depan ada di bagian atas.']];
const FV={F:[[0,0,1],[1,0,0],[0,-1,0]],R:[[1,0,0],[0,0,-1],[0,-1,0]],B:[[0,0,-1],[-1,0,0],[0,-1,0]],L:[[-1,0,0],[0,0,1],[0,-1,0]],U:[[0,1,0],[1,0,0],[0,0,1]],D:[[0,-1,0],[1,0,0],[0,0,-1]]};
const cell=(f,i,j)=>{const[n,r,d]=FV[f],c=n.map((v,k)=>v+(j-1)*r[k]+(i-1)*d[k]);return IX[c.join()+'|'+n.join()]};
let FILL=Array(54).fill('N'),mode='fill',fi=0,sw=false;
const go=d=>{const n=Math.max(0,Math.min(5,fi+d));if(n===fi)return;fi=n;upd(1)};
function solverUI(){return '<div id="sv"></div>'}
function draw(){const v=$('#sv');if(!v)return;mode==='fill'?drawFill(v):drawRes(v)}
const VW={F:[-12,-18],R:[-12,-108],B:[-12,-198],L:[-12,-288],U:[-72,0],D:[72,0]};
const paintF=()=>document.querySelectorAll('.sk').forEach(e=>{e.style.background=CM[FILL[e.dataset.i]]});
function tabs(){const t=$('#tabs');if(!t)return;t.innerHTML=FACES.map(([k,n],i)=>{let c=0;SL.forEach((s,j)=>{if(s.f===k&&FILL[j]!=='N')c++});return `<button data-f="${i}" class="${i===fi?'on':''}">${n} ${c}/9</button>`}).join('');
 t.querySelectorAll('button').forEach(b=>b.onclick=()=>{fi=+b.dataset.f;upd(1)})}
function upd(anim){const f=FACES[fi];tabs();
 $('#fh').innerHTML=`<b>Sisi ${f[1]}.</b> ${f[2]} Titik gelap di tengah adalah pusat sisi.`;
 $('#fl').textContent=`Sisi ${f[1]} · ${fi+1}/6`;$('#pv').disabled=!fi;$('#nx').disabled=fi>4;
 document.querySelectorAll('.sk').forEach(e=>e.classList.toggle('off',SL[e.dataset.i].f!==f[0]));
 let[t,u]=VW[f[0]];u+=360*Math.round((ry-u)/360);rx=t;ry=u;
 const c=$('#cube');if(!anim)c.style.transition='none';view();if(!anim){void c.offsetWidth;c.style.transition=''}}
function drawFill(v){
 v.innerHTML=`<div class="stage" id="stg"><div id="cube" class="mv"></div></div>
<div class="nv2"><button class="ar" id="pv" aria-label="Sisi sebelumnya">&lt;</button><b id="fl"></b><button class="ar" id="nx" aria-label="Sisi berikutnya">&gt;</button></div>
<div class="row pal" id="pal">${'WYROBG'.split('').map(c=>`<button data-c="${c}" style="background:${CM[c]}" aria-label="Warna ${c}"></button>`).join('')}<button data-c="N" class="er" aria-label="Hapus warna">✕</button></div>
<div id="tabs" class="tabs" style="margin-top:16px"></div>
<p id="fh" style="margin-bottom:14px;min-height:4.8em"></p>
<div class="row"><button class="btn" id="bs">Selesaikan</button><button class="btn alt" id="bk">Isi contoh acak</button><button class="btn alt" id="bc">Hapus semua</button></div>
<p id="msg" style="text-align:center;margin-top:14px"></p>`;
 cs=1.45;
 SL.forEach((s,i)=>{const e=document.createElement('div');e.className='sk'+(CTR.includes(i)?' ct':'');e.dataset.i=i;e.style.transform=BT(i);
  e.onclick=()=>{if(SL[i].f!==FACES[fi][0])return;FILL[i]=pc;e.style.background=CM[pc];clrBad();tabs();msg('')};$('#cube').appendChild(e)});
 paintF();upd(0);
 const pal=v.querySelectorAll('#pal button'),sel=()=>pal.forEach(b=>b.classList.toggle('on',b.dataset.c===pc));pal.forEach(b=>b.onclick=()=>{pc=b.dataset.c;sel()});sel();
 $('#pv').onclick=()=>go(-1);$('#nx').onclick=()=>go(1);
 $('#bc').onclick=()=>{FILL=Array(54).fill('N');fi=0;paintF();upd(1);msg('')};
 $('#bk').onclick=()=>{FILL=randState();paintF();tabs();msg('Contoh acak sudah terisi. Tekan Selesaikan.')};
 $('#bs').onclick=()=>{const v=periksaIsian(FILL);if(v.length)return laporKesalahan(v);clrBad();startSolve(FILL.slice())};
}
let ERR=[];
const clrBad=()=>document.querySelectorAll('.sk.bad').forEach(e=>e.classList.remove('bad'));
function laporKesalahan(v){
 ERR=v;const m=$('#msg');if(!m)return;
 m.innerHTML=`<div class="errbox" role="alert"><b>Ada ${v.length} hal yang perlu dicek:</b><ul>${v.map((x,k)=>`<li>${fm(x.pesan)}${x.sisi?` <button class="btn alt xs" data-e="${k}">Tunjukkan</button>`:''}</li>`).join('')}</ul></div>`;
 m.querySelectorAll('[data-e]').forEach(b=>b.onclick=()=>tunjuk(ERR[+b.dataset.e]));
 m.scrollIntoView({block:'nearest',behavior:'smooth'})}
function tunjuk(x){clrBad();const k=FACES.findIndex(f=>f[0]===x.sisi);if(k>=0)fi=k;
 x.sel.forEach(i=>{const e=document.querySelector('.sk[data-i="'+i+'"]');if(e)e.classList.add('bad')});
 upd(1);const st=$('#stg');if(st)st.scrollIntoView({block:'center',behavior:'smooth'})}
function notifUlang(){const c=$('#cur');if(!c)return;
 c.innerHTML=`<div class="cw"><div><b>Langkah solusi dihapus</b><span>Rumus tadi mengubah posisi kubus, jadi langkah sebelumnya tidak berlaku lagi.</span></div><button class="btn" id="hu">Hitung dari sini</button></div>`;
 $('#hu').onclick=()=>startSolve(S.slice())}
const randState=()=>{let t=home();const F='UDRLFB',m=["","'","2"];let l='',n=0;while(n<25){const x=F[Math.random()*6|0];if(x===l)continue;l=x;n++;const q=tok(x+m[Math.random()*3|0]);t=ap(t,TP(q.n,q.k))}return t};
let SOL0=[],solving=false;
function startSolve(st){if(solving)return;solving=true;msg(READY?'Menghitung…':'Menyiapkan solver…');
 prepAsync().then(()=>{msg('Menghitung…');setTimeout(()=>{const r=solve(st);solving=false;if(!r)return msg(WHY[solveWhy]||'Kubus ini tidak bisa diselesaikan. Cek lagi tiap sisi dengan kubus aslimu.');if(!cekSolusi(st,r))return msg('Hasil solver gagal diperiksa ulang. Tekan Selesaikan sekali lagi.');
  FILL=st.slice();SOL0=quarters(r);SOL=SOL0.slice();pi=0;S=FILL.slice();mode='res';draw()},30)})}
function drawRes(v){
 v.innerHTML=`<div class="stage" id="stg"><div id="cube"></div></div><div id="cur"></div><div id="msg"></div><div class="chips" id="sol"></div>
<div class="row" style="justify-content:flex-start"><button class="btn alt" id="pb">◀ Mundur</button><button class="btn" id="pa">▶ Putar otomatis</button><button class="btn alt" id="pf">Maju ▶</button></div>
${spTabs()}
<h2>Coba rumus</h2><div class="row" style="justify-content:flex-start"><input class="mi" id="mi" placeholder="R U R' U'" autocapitalize="off" autocomplete="off"><button class="btn alt" id="mj">Jalankan</button></div>
<div class="row" style="justify-content:flex-start;margin-top:22px"><button class="btn alt" id="bo">↺ Ulangi dari awal</button><button class="btn alt" id="bz">🎲 Acak kubus</button><button class="btn alt" id="br">Kubus rapi</button><button class="btn alt" id="bf">← Ubah warna</button></div>`;
 SL.forEach((s,i)=>{const e=document.createElement('div');e.className='sk';e.dataset.i=i;e.style.transform=BT(i);$('#cube').appendChild(e)});
 S=FILL.slice();for(let i=0;i<pi;i++){const q=tok(SOL[i]);S=ap(S,TP(q.n,q.k))}cs=1;rx=-28;ry=-38;view();paintAll();chips();bindSp();
 msg(SOL.length?`${SOL.length} langkah. Tekan Maju atau Putar otomatis.`:'Kubus sudah selesai.');
 $('#bf').onclick=async()=>{await halt();mode='fill';clr();draw()};
 $('#bo').onclick=async()=>{await halt();S=FILL.slice();SOL=SOL0.slice();pi=0;paintAll();chips();msg(SOL.length?`${SOL.length} langkah. Tekan Maju atau Putar otomatis.`:'Kubus sudah selesai.')};
 $('#br').onclick=async()=>{await halt();FILL=home();SOL0=[];SOL=[];pi=0;S=FILL.slice();paintAll();chips();msg('Kubus sudah rapi. Coba Acak kubus, atau ketik rumus di kolom Coba rumus.')};
 $('#bz').onclick=async()=>{await halt();clr();startSolve(randState())};
 $('#mj').onclick=async()=>{await halt();const v=periksaRumus($('#mi').value);if(!v.ok)return msg(v.pesan);clr();msg('');await runSeq(quarters(expand(v.teks)));if(!isRapi(S))notifUlang()};
 $('#mi').onkeydown=e=>{if(e.key==='Enter')$('#mj').click()};
 $('#pf').onclick=async()=>{if(busy||auto)await halt();await fwd()};
 $('#pb').onclick=async()=>{if(busy||auto)await halt();await back()};
 $('#pa').onclick=async()=>{const b=$('#pa');if(auto){haltNow();return}
  if(!SOL.length||pi>=SOL.length)return;await halt();auto=true;const id=runId;b.textContent='Jeda';
  while(auto&&id===runId&&pi<SOL.length){if(!await fwd())break;if(pi>=SOL.length)break;await sleep(spd.gap,id)}
  if(id===runId){auto=false;const x=$('#pa');if(x)x.textContent='▶ Putar otomatis'}};
}
const WHY={fail:'Solver kehabisan waktu mencari langkah. Tekan Selesaikan sekali lagi.',twist:'Ada satu sudut kubus yang terpuntir. Biasanya satu stiker sudut salah warna.',flip:'Ada satu sisi (edge) yang terbalik. Biasanya dua stiker pada satu edge tertukar.',parity:'Ada dua bagian kubus yang tertukar posisi. Cek lagi warna tiap sisi.',piece:'Ada kombinasi warna yang tidak mungkin ada di kubus asli. Cek lagi sudut dan sisi yang warnanya salah.'};
const desc=t=>{const q=tok(t);if(!q)return '';const side=FNM[q.n]||WF[q.n];
 if(side)return `Putar ${FNM[q.n]?'sisi':'dua lapis'} ${side} ${q.k===2?'180°':q.k>0?'searah jarum jam':'berlawanan jarum jam'}, dilihat dari sisi ${side}`;
 return `Putar ${DN[q.n]}${q.k===2?' 180°':q.k<0?', arah kebalikannya':''}`};
const algToks=a=>a.replace(/\)\s*\d+/g,')').replace(/[()]/g,' ').trim().split(/\s+/).filter(t=>tok(t));
const artRow=a=>{const ts=algToks(a);return ts.length>16?'':`<div class="mvs">${ts.map(t=>`<div class="mv1" title="${fm(desc(t))}">${moveArt(t,88)}<b>${fm(t)}</b></div>`).join('')}</div>`};
const att=s=>s.replace(/"/g,'&quot;');
const MU0='Pegang kubus dengan sisi hijau menghadap kamu dan kuning di atas (posisi standar), lalu mulai dari posisi itu.';
const MU={cross:'Putih di bawah, hijau di depan. Putar kubus sampai edge putih-hijau berada di posisi seperti gambar. Edge ini dimasukkan ke slot depan-bawah.',
 f2l:'Putih di bawah, hijau di depan. Corner putih-hijau-merah dan edge hijau-merah harus berada seperti gambar. Rumus memasukkannya ke slot kanan depan. Kalau posisinya hanya beda putaran U, putar U sampai sama.',
 oll:'Kuning di atas, hijau di depan. Putar U sampai pola kuning sama persis dengan gambar (bagian bawah gambar adalah sisi depan, yang menghadap kamu).',
 pll:'Kuning di atas, hijau di depan. Putar U sampai pola warna batang di pinggir sama dengan gambar (bagian bawah gambar adalah sisi depan). Setelah rumus, putar U sampai semua sisi cocok.',
 cmll:'Kuning di atas, hijau di depan, dua blok ada di kiri dan kanan. Putar U sampai posisi dan warna corner sama dengan gambar (bagian bawah gambar adalah sisi depan).'};
const muP=t=>`<p class="mu"><b>Mulai dari:</b> ${fm(t)}</p>`;
const muHtml=(k,x)=>{let t=MU[k]||MU0;const f=x.a.trim().split(/\s+/)[0];if(/^[xyz]/.test(f))t+=` Rumus ini diawali ${f}: putar seluruh kubus lebih dulu. Di akhir rumus kubus tidak kembali sendiri, jadi lakukan ${f.endsWith("'")?f[0]:f+"'"} untuk mengembalikannya.`;return muP(t)};
const ag=(a,c)=>a.map(x=>`<div class="alg" style="--c:${C[c]}"><div class="ah"><b>${fm(x.n)}</b><div class="ba"><button class="cp" data-a="${att(x.a)}">Salin</button><button class="pl" data-a="${att(x.a)}">▶ Peragakan</button></div></div><code>${fm(x.a)}</code>${muP(x.m||MU0)}${artRow(x.a)}<span>${fm(x.d)}</span></div>`).join('');

/* ===== Blok materi lengkap (metode, tahap, dan kasus) ===== */
const invAlg=a=>a.trim().split(/\s+/).reverse().map(t=>{const q=tok(t);return q.n+(q.k===2?'2':q.k>0?"'":'')}).join(' ');
const fixRot=a=>{const t=a.trim().split(/\s+/);return /^[xyz]/.test(t[0])?a+' '+(t[0].endsWith("'")?t[0][0]:t[0]+"'"):a};
const caseStart=a=>ap(home(),seqP(invAlg(fixRot(a))));
function casesHtml(b,c){let a=KASUS[b.k].slice();if(b.ids)a=b.ids.map(n=>a.find(x=>x.no===n));if(b.names2)a=b.names2.map(n=>a.find(x=>x.nm===n));let last='';
 return `<div class="kas">`+a.map((x,i)=>{const tt=b.names&&b.names[i]?`${b.label} ${x.no}: ${b.names[i]}`:x.nm?`${b.label}: ${x.nm}`:`${b.label} ${x.no}`;let gh='';if(b.group&&x.g!==last){last=x.g;gh=`<h3 class="kg">${fm(x.g)}</h3>`}
  return gh+`<div class="alg ks" style="--c:${C[c]}"><img class="kimg" src="seni/gambar/${x.img}" width="132" height="132" alt="${att(tt)}" loading="lazy"><div class="kb"><div class="ah"><b>${fm(tt)}</b><div class="ba"><button class="cp" data-a="${att(x.a)}">Salin</button><button class="pl" data-a="${att(x.a)}" data-su="1">▶ Peragakan</button></div></div><code>${fm(x.a)}</code><span>${fm(x.h)}</span>${muHtml(b.k,x)}${artRow(x.a)}</div></div>`}).join('')+`</div>`}
function blocksHtml(bs,c){return bs.map(b=>{switch(b.t){
 case 'p':return `<p>${fm(b.x)}</p>`;
 case 'h':return `<h2>${fm(b.x)}</h2>`;
 case 'h3':return `<h3>${fm(b.x)}</h3>`;
 case 'ul':return `<ul class="bl">${b.x.map(t=>`<li>${fm(t)}</li>`).join('')}</ul>`;
 case 'ol':return `<ol class="s">${b.x.map(t=>`<li>${fm(t)}</li>`).join('')}</ol>`;
 case 'tip':return `<div class="tip">${fm(b.x)}</div>`;
 case 'stages':return `<div class="stg">${b.x.map(s=>`<figure><img src="${s.img}" width="200" height="200" alt="${att(s.n)}" loading="lazy"><figcaption><b>${fm(s.n)}</b><span>${fm(s.d)}</span></figcaption></figure>`).join('')}</div>`;
 case 'algs':return ag(b.x,c);
 case 'tbl':return `<div class="tw"><table><thead><tr>${b.head.map(x=>`<th>${fm(x)}</th>`).join('')}</tr></thead><tbody>${b.rows.map(r=>`<tr>${r.map((x,i)=>`<td${i?'':' class="k"'}>${fm(x)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
 case 'cases':return casesHtml(b,c)}return ''}).join('')}
/* ===== Demo kubus 3D di halaman materi ===== */
const DL0='Tekan “▶ Peragakan” pada rumus di bawah, kubus akan berputar. Posisi awal: depan hijau, atas kuning, kanan merah.';
const demoUI=()=>`<div class="demo" id="dm"><div class="stage" id="stg3"><div id="cube"></div></div><div class="dmb"><b id="dl">${DL0}</b><button class="btn alt" id="dr">Reset</button></div></div>${spTabs()}`;
function initDemo(){SL.forEach((s,i)=>{const e=document.createElement('div');e.className='sk'+(CTR.includes(i)?' ct':'');e.dataset.i=i;if(CTR.includes(i))e.dataset.l=s.f;e.style.transform=BT(i);$('#cube').appendChild(e)});
 S=home();cs=.82;rx=-28;ry=-38;view();paintAll();$('#dr').onclick=async()=>{await halt();S=home();paintAll();$('#dl').textContent=DL0}}
async function demo(a,su){if(!$('#dm'))return;await halt();const ts=expand(a).filter(t=>tok(t)).slice(0,40);if(!ts.length)return;
 S=su?caseStart(a):home();paintAll();const id=runId,lb=$('#dl');
 await runSeq(ts,false,spd.gap+250,spd.dur+160,(i,t)=>{lb.textContent=`${i+1}/${ts.length} · ${fm(t)}: ${desc(t)}`});
 if(id===runId&&lb)lb.textContent='Selesai. Tekan ▶ Peragakan lagi, atau Reset.'}
/* ===== Magic: gerakan berulang yang kembali normal ===== */
const MG=[{a:'M U',t:'Dasar magic'},{a:"M' U"},{a:"M U M' U"},{a:"M U M U'"},{a:"M U M' U'"},{a:'M U2'},{a:'M2 U'},{a:'M2 U2'},{a:"M2 U M2 U'"},
{a:"R U R' U'",t:'Sexy move'},{a:"R' F R F'",t:'Sledgehammer'},{a:"F R U R' U' F'"},{a:"R U R' U R U2 R'",t:'Sune'},{a:"R U2 R' U' R U' R'",t:'Anti-Sune'},{a:'R2 U2'},{a:"R2 U R2 U'"},{a:"r U r' U'"},{a:'R U2'},{a:"R L'"},{a:"U D'"},
{a:'M E S'},{a:'M2 E2 S2',t:'Pola papan catur'},{a:'R2 L2 U2 D2 F2 B2',t:'Putar semua sisi 180°'},{a:"F2 B2 U D' R2 L2 U D'",t:'Pons asinorum'},{a:'x y',t:'Putar seluruh kubus'},{a:"U R' U' R F R F'"}];
const orderOf=a=>{const p=seqP(a),h=home().join();let s=home(),n=0;do{s=ap(s,p);n++}while(s.join()!==h&&n<500);return n};
let mgi=0,mgk=0,mauto=false,mmode='jel',mlv='all';
const mgToks=()=>quarters(MG[mgi].a.split(' '));
const LVN={easy:'Easy',normal:'Normal',hard:'Hard'},lvOf=t=>t<=30?'easy':t<=80?'normal':'hard';
function magicUI(){return `<div id="mgv"><div class="stage" id="stg2"><div id="cube"></div></div>
<div class="tabs" id="mmode"><span class="tl">Mode</span><button data-m="jel">Jelajah magic</button><button data-m="gm">🎩 Tantangan sulap</button></div>
<div id="mj"><p id="mt" class="mt"></p><div class="chips" id="mc"></div>
${spTabs()}
<div class="row" style="justify-content:flex-start"><button class="btn" id="mp">▶ Mainkan</button><button class="btn alt" id="mr">↺ Ulangi dari awal</button><button class="btn alt" id="mx">🎲 Acak magic</button></div>
<h2>Pilih magic</h2><p style="color:var(--mut)">Tingkat kesulitan dihitung dari total gerakan sampai kubus kembali normal: Easy sampai 30 gerakan, Normal sampai 80, Hard lebih dari itu.</p><div class="tabs" id="mlv"></div><div class="grid" id="ml"></div></div>
<div id="gm" hidden>${gameUI()}</div></div>`}
function updMagic(){const m=MG[mgi],tk=mgToks(),tot=tk.length*m.o,fin=mgk>=tot,rep=fin?m.o:Math.floor(mgk/tk.length)+1;
 $('#mt').innerHTML=fin?`<b>Kembali normal ✓</b> Setelah ${m.o} kali ulangan, kubus rapi lagi.`:`<b>${fm(m.a)}</b> · ulangan ${rep} dari ${m.o} (kembali normal di ulangan ke-${m.o}) · total ${tot} gerakan`;
 $('#mc').innerHTML=tiles(tk,fin?tk.length:mgk%tk.length);
 document.querySelectorAll('.mcd').forEach(b=>b.classList.toggle('on',+b.dataset.i===mgi))}
const stopMagic=()=>halt();
async function pickMagic(i){await stopMagic();mgi=i;mgk=0;S=home();paintAll();$('#mp').textContent='▶ Mainkan';updMagic()}
async function magicPlay(){const b=$('#mp');if(mauto){mauto=false;return}if(busy)return;
 const tk=mgToks(),tot=tk.length*MG[mgi].o;if(mgk>=tot){mgk=0;S=home();paintAll()}
 mauto=true;busy=true;b.textContent='⏸ Jeda';
 while(mauto&&mgk<tot){await play(tk[mgk%tk.length],false,spd.dur);mgk++;updMagic();for(let w=0;w<spd.gap/50&&mauto&&mgk<tot;w++)await wait(50)}
 busy=false;mauto=false;const x=$('#mp');if(x)x.textContent=mgk>=tot?'↻ Mainkan lagi':'▶ Lanjutkan'}
function listMagic(){const cnt={all:MG.length,easy:0,normal:0,hard:0};MG.forEach(m=>cnt[m.lv]++);
 $('#mlv').innerHTML=`<span class="tl">Tingkat</span>`+[['all','Semua'],['easy','Easy'],['normal','Normal'],['hard','Hard']].map(([k,n])=>`<button data-k="${k}" class="${mlv===k?'on':''}">${n} (${cnt[k]})</button>`).join('');
 $('#ml').innerHTML=MG.map((m,i)=>mlv==='all'||m.lv===mlv?`<button class="card mcd${i===mgi?' on':''}" data-i="${i}" style="--c:var(--${{easy:'g',normal:'y',hard:'r'}[m.lv]})"><code>${fm(m.a)}</code><small><span class="lvb ${m.lv}">${LVN[m.lv]}</span> ${m.t?m.t+' · ':''}kembali normal setelah ${m.o} kali · total ${m.tot} gerakan</small></button>`:'').join('');
 document.querySelectorAll('#mlv button').forEach(b=>b.onclick=()=>{mlv=b.dataset.k;listMagic()});
 document.querySelectorAll('.mcd').forEach(b=>b.onclick=()=>{pickMagic(+b.dataset.i);window.scrollTo({top:$('#stg2').getBoundingClientRect().top+scrollY-70,behavior:'smooth'})})}
async function setMode(m){await halt();gAbort();mmode=m;S=home();paintAll();$('#mj').hidden=m!=='jel';$('#gm').hidden=m!=='gm';
 document.querySelectorAll('#mmode button').forEach(b=>b.classList.toggle('on',b.dataset.m===m));if(m==='gm')gInit();else{mgk=0;$('#mp').textContent='▶ Mainkan';updMagic()}}
function initMagic(){MG.forEach(m=>{if(!m.o)m.o=orderOf(m.a);m.tot=quarters(m.a.split(' ')).length*m.o;m.lv=lvOf(m.tot)});
 SL.forEach((s,i)=>{const e=document.createElement('div');e.className='sk';e.dataset.i=i;e.style.transform=BT(i);$('#cube').appendChild(e)});
 S=home();cs=1;rx=-28;ry=-38;view();paintAll();mgk=0;mmode='jel';
 listMagic();
 $('#mx').onclick=()=>{let i;do{i=Math.random()*MG.length|0}while(i===mgi&&MG.length>1);pickMagic(i)};
 $('#mp').onclick=magicPlay;$('#mr').onclick=async()=>{await stopMagic();mgk=0;S=home();paintAll();$('#mp').textContent='▶ Mainkan';updMagic()};
 document.querySelectorAll('#mmode button').forEach(b=>{b.classList.toggle('on',b.dataset.m==='jel');b.onclick=()=>setMode(b.dataset.m)});
 gBind();updMagic()}
/* ===== Tantangan sulap: tiga fase (Easy, Normal, Hard) ===== */
const GL={easy:{n:4,gap:700,dur:380,par:60,base:100,mult:1,hint:5,peek:0,peeks:99,slice:false,dbl:false,info:'4 gerakan sederhana. Daftar langkah sulap selalu terlihat. Petunjuk −5 poin.'},
 normal:{n:8,gap:450,dur:300,par:120,base:250,mult:2,hint:10,peek:8,peeks:3,slice:false,dbl:true,info:'8 gerakan, termasuk putaran 180°. Daftar langkah disembunyikan setelah pertunjukan. Boleh mengintip 3 kali (−8 poin). Petunjuk −10 poin.'},
 hard:{n:14,gap:260,dur:230,par:240,base:500,mult:3,hint:15,peek:15,peeks:2,slice:true,dbl:true,info:'14 gerakan, termasuk 180° dan lapisan tengah M, E, S. Pertunjukan cepat dan daftar disembunyikan. Boleh mengintip 2 kali (−15 poin). Petunjuk −15 poin.'}};
const GKEY='rubik-sulap';let G={lv:'easy',st:'idle',spell:[],stack:[],hist:[],moves:0,opt:0,hints:0,peeks:0,undo:0,t0:0,iv:0,q:[],qrun:false,wins:0};
const invTok=t=>t.endsWith("'")?t.slice(0,-1):t+"'";
const loadG=()=>{try{return JSON.parse(localStorage.getItem(ukey(GKEY))||'{}')}catch(e){return{}}};
const saveG=r=>{try{localStorage.setItem(ukey(GKEY),JSON.stringify(r))}catch(e){}};
const FACEI={};'URFDLB'.split('').forEach(f=>FACEI[f]=SL.map((s,i)=>s.f===f?i:-1).filter(i=>i>=0));
const facesDone=()=>'URFDLB'.split('').every(f=>FACEI[f].every(i=>S[i]===S[FACEI[f][0]]));
function gameUI(){return `<div class="tabs" id="glv"></div><p id="gi" class="gi"></p>
<div class="row" style="justify-content:flex-start"><button class="btn" id="gs">✨ Mulai sulap</button><button class="btn alt" id="gr">⟲ Ulangi level</button></div>
<div class="gst" id="gst"></div><div id="gh" class="gh"></div>
<div class="chips" id="gc"></div>
<div class="pad" id="gpad"></div>
<div class="row" style="justify-content:flex-start"><button class="btn alt" id="gu">↩ Undo</button><button class="btn alt" id="gt">💡 Petunjuk</button><button class="btn alt" id="gp">👁 Intip langkah</button></div>
<div id="gres"></div><div id="grec" class="grec"></div>`}
function genSpell(L){const f='URFDLB',sl=['M','E','S'],ax={U:1,D:1,E:1,R:0,L:0,M:0,F:2,B:2,S:2},o=[];
 while(o.length<L.n){const n=L.slice&&Math.random()<.3?sl[Math.random()*3|0]:f[Math.random()*6|0],last=o.length?o[o.length-1][0]:'',l2=o.length>1?o[o.length-2][0]:'';
  if(n===last||(o.length>1&&ax[n]===ax[last]&&ax[n]===ax[l2]))continue;const r=Math.random();o.push(n+(L.dbl&&r<.22?'2':r<.6?'':"'"))}
 return o}
const gMoves=()=>{const m=[];for(const f of 'URFDLB')m.push(f);for(const f of 'URFDLB')m.push(f+"'");if(GL[G.lv].slice){for(const f of 'MES')m.push(f);for(const f of 'MES')m.push(f+"'")}return m};
function gPad(){const pad=$('#gpad');if(!pad)return;pad.innerHTML=gMoves().map(m=>`<button data-m="${m}" aria-label="${fm(desc(m))}" title="${fm(desc(m))}">${fm(m)}</button>`).join('');pad.querySelectorAll('button').forEach(b=>b.onclick=()=>gPress(b.dataset.m))}
function gRecHtml(){const r=loadG(),x=r[G.lv]||{};return `<b>Rekor ${LVN[G.lv]}:</b> skor terbaik ${x.best||'-'} · waktu tercepat ${x.time?x.time.toFixed(1)+' dtk':'-'} · bintang terbaik ${x.stars?'★'.repeat(x.stars):'-'} · menang ${x.wins||0} dari ${x.plays||0} main`}
function gTabs(){const r=loadG();$('#glv').innerHTML=`<span class="tl">Fase</span>`+['easy','normal','hard'].map((k,i)=>{const x=r[k]||{};return `<button data-l="${k}" class="${G.lv===k?'on':''}">${i+1}. ${LVN[k]} · ${GL[k].n}${x.stars?' '+'★'.repeat(x.stars):''}</button>`}).join('');
 document.querySelectorAll('#glv button').forEach(b=>b.onclick=async()=>{if(G.st==='show')return;await halt();gAbort();G.lv=b.dataset.l;S=home();paintAll();gInit()})}
function gStat(){const sec=G.st==='play'?(performance.now()-G.t0)/1000:G.tEnd||0,st=$('#gst');if(!st)return;
 st.innerHTML=`<div><small>Waktu</small><b>${sec.toFixed(1)}</b></div><div><small>Gerakanmu</small><b>${G.moves}</b></div><div><small>Ideal</small><b>${G.opt||'-'}</b></div><div><small>Petunjuk</small><b>${G.hints}</b></div><div><small>Intip</small><b>${G.peeks}${GL[G.lv].peeks<99?'/'+GL[G.lv].peeks:''}</b></div>`}
function gAbort(){clearInterval(G.iv);G.st='idle';G.q=[];G.qrun=false}
function gInit(){gAbort();G.moves=0;G.opt=0;G.hints=0;G.peeks=0;G.spell=[];G.stack=[];G.hist=[];G.tEnd=0;gTabs();gPad();
 $('#gi').textContent=GL[G.lv].info;$('#gs').textContent='✨ Mulai sulap';$('#gc').innerHTML='';$('#gh').innerHTML='';$('#gres').innerHTML='';$('#grec').innerHTML=gRecHtml();
 $('#gpad').classList.add('off');['gu','gt','gp','gr'].forEach(i=>$('#'+i).disabled=true);gStat()}
let gKey=false;
function gBind(){$('#gs').onclick=gStart;$('#gr').onclick=gRetry;$('#gu').onclick=gUndo;$('#gt').onclick=gHint;$('#gp').onclick=gPeek;
 if(gKey)return;gKey=true;
 document.addEventListener('keydown',e=>{if(G.st!=='play'||!$('#gm')||$('#gm').hidden||/^(INPUT|TEXTAREA)$/.test(e.target.tagName)||e.ctrlKey||e.metaKey||e.altKey)return;const k=e.key.toUpperCase();if(!'URFDLBMES'.includes(k)||k.length!==1)return;const m=k+(e.shiftKey?"'":'');if(!gMoves().includes(m))return;e.preventDefault();gPress(m)})}
async function gStart(){if(G.st==='show')return;await halt();gAbort();const L=GL[G.lv],r=loadG();r[G.lv]=r[G.lv]||{};r[G.lv].plays=(r[G.lv].plays||0)+1;saveG(r);
 gInit();S=home();paintAll();G.spell=genSpell(L);const qs=quarters(G.spell);G.stack=qs.map(invTok);G.opt=qs.length;G.st='show';
 $('#gs').textContent='🎩 Sulap berjalan…';$('#gh').innerHTML='<b>Perhatikan!</b> Ingat urutan geraknya, lalu kembalikan kubus seperti semula.';$('#grec').innerHTML=gRecHtml();gStat();
 const id=runId;busy=true;
 for(let i=0;i<G.spell.length&&id===runId;i++){$('#gc').innerHTML=tiles(G.spell,i);const q=tok(G.spell[i]);const n=q.k===2?[q.n,q.n]:[G.spell[i]];for(const t of n){if(id!==runId)break;await play(t,false,L.dur);if(t!==n[n.length-1])await sleep(80,id)}
  if(id!==runId)break;await sleep(L.gap,id)}
 busy=false;if(id!==runId||mmode!=='gm'||!$('#gm'))return;
 $('#gc').innerHTML=G.lv==='easy'?tiles(G.spell,G.spell.length):'<span style="color:var(--mut)">Langkah disembunyikan. Gunakan Intip kalau lupa.</span>';
 G.st='play';G.t0=performance.now();G.iv=setInterval(()=>{if(!$('#gm')||$('#gm').hidden){clearInterval(G.iv);return}gStat()},200);
 $('#gs').textContent='✨ Sulap baru';$('#gh').innerHTML='<b>Giliranmu!</b> Tekan tombol gerakan (atau papan ketik: huruf, Shift untuk ’) sampai kubus rapi lagi.';
 $('#gpad').classList.remove('off');['gu','gt','gp','gr'].forEach(i=>$('#'+i).disabled=false);gStat()}
function gPress(m){if(G.st!=='play')return;G.q.push(m);if(!G.qrun)gRunQ()}
async function gRunQ(){G.qrun=true;const id=runId;while(G.q.length&&G.st==='play'&&id===runId){const m=G.q.shift();G.hist.push({m,stack:G.stack.slice()});
  if(G.stack.length&&G.stack[G.stack.length-1]===m)G.stack.pop();else G.stack.push(invTok(m));G.moves++;gStat();busy=true;await play(m,false,150);busy=false;
  if(G.st==='play'&&facesDone()){gWin();break}}G.qrun=false}
async function gUndo(){if(G.st!=='play'||G.qrun||!G.hist.length)return;const h=G.hist.pop();G.stack=h.stack;G.moves--;G.undo++;busy=true;await play(h.m,true,150);busy=false;gStat()}
function gHint(){if(G.st!=='play'||!G.stack.length)return;const t=G.stack[G.stack.length-1];G.hints++;gStat();
 $('#gh').innerHTML=`<div class="cw">${moveArt(t,72)}<div><b>Petunjuk: ${fm(t)}</b><span>${fm(desc(t))}</span></div></div>`;
 document.querySelectorAll('#gpad button').forEach(b=>b.classList.toggle('hint',b.dataset.m===t));setTimeout(()=>document.querySelectorAll('#gpad button.hint').forEach(b=>b.classList.remove('hint')),2500)}
function gPeek(){const L=GL[G.lv];if(G.st!=='play')return;if(G.lv==='easy'){$('#gc').innerHTML=tiles(G.spell,G.spell.length);return}
 if(G.peeks>=L.peeks){$('#gh').innerHTML='<b>Jatah mengintip habis.</b>';return}G.peeks++;gStat();$('#gc').innerHTML=tiles(G.spell,G.spell.length);
 const id=G.t0;setTimeout(()=>{if(G.st==='play'&&G.t0===id)$('#gc').innerHTML='<span style="color:var(--mut)">Langkah disembunyikan lagi.</span>'},4000)}
async function gRetry(){if(G.st==='show')return;await halt();if(!G.spell.length)return;const qs=quarters(G.spell);S=home();qs.forEach(t=>{const q=tok(t);S=ap(S,TP(q.n,q.k))});paintAll();
 clearInterval(G.iv);G.st='play';G.stack=qs.map(invTok);G.hist=[];G.q=[];G.moves=0;G.hints=0;G.peeks=0;G.undo=0;G.t0=performance.now();$('#gres').innerHTML='';$('#gh').innerHTML='<b>Ulang dari kubus acak yang sama.</b>';
 $('#gpad').classList.remove('off');['gu','gt','gp','gr'].forEach(i=>$('#'+i).disabled=false);G.iv=setInterval(()=>{if(!$('#gm')||$('#gm').hidden){clearInterval(G.iv);return}gStat()},200);gStat()}
function gWin(){clearInterval(G.iv);G.st='win';const L=GL[G.lv],sec=(performance.now()-G.t0)/1000;G.tEnd=sec;const extra=Math.max(0,G.moves-G.opt),pen=G.hints+G.peeks;
 const stars=pen===0&&extra<=2?3:pen<=2&&extra<=Math.max(4,Math.ceil(G.opt*.6))?2:1;
 const score=Math.max(0,Math.round(L.base*stars/3+Math.min(L.base*.6,Math.max(0,L.par-sec)*L.mult)-G.hints*L.hint-G.peeks*L.peek-extra*2));
 const r=loadG(),x=r[G.lv]=r[G.lv]||{};x.wins=(x.wins||0)+1;let nb=false;if(!x.best||score>x.best){x.best=score;nb=true}if(!x.time||sec<x.time)x.time=sec;if(!x.stars||stars>x.stars)x.stars=stars;saveG(r);
 const nxt={easy:'normal',normal:'hard'}[G.lv];
 $('#gpad').classList.add('off');['gu','gt','gp'].forEach(i=>$('#'+i).disabled=true);gStat();$('#gh').innerHTML='';
 $('#gres').innerHTML=`<div class="win"><div class="stars">${'★'.repeat(stars)}${'☆'.repeat(3-stars)}</div><b>Kubus kembali normal! Skor ${score}${nb?' · rekor baru!':''}</b><p>Waktu ${sec.toFixed(1)} dtk · ${G.moves} gerakan (ideal ${G.opt}) · petunjuk ${G.hints} · intip ${G.peeks}</p><div class="row" style="justify-content:flex-start"><button class="btn" id="g1">Main lagi</button>${nxt?`<button class="btn alt" id="g2">Lanjut ke ${LVN[nxt]}</button>`:''}</div></div>`;
 $('#g1').onclick=gStart;if(nxt)$('#g2').onclick=async()=>{G.lv=nxt;S=home();paintAll();gInit();gStart()};$('#grec').innerHTML=gRecHtml();gTabs()}
const quarters=a=>a.flatMap(t=>{const q=tok(t);return q.k===2?[q.n,q.n]:[t]});
const spds={slow:{gap:1100,dur:700},normal:{gap:350,dur:420},fast:{gap:60,dur:200}};let spd=spds.normal;
const spTabs=()=>`<div class="tabs" data-sp><span class="tl">Kecepatan</span>${[['slow','Pelan'],['normal','Normal'],['fast','Cepat']].map(([k,n])=>`<button data-s="${k}" class="${spds[k]===spd?'on':''}">${n}</button>`).join('')}</div>`;
const bindSp=()=>document.querySelectorAll('[data-sp] button').forEach(b=>b.onclick=()=>{spd=spds[b.dataset.s];document.querySelectorAll('[data-sp] button').forEach(x=>x.classList.toggle('on',x.dataset.s===b.dataset.s))});
const wait=ms=>new Promise(r=>setTimeout(r,ms));
let runId=0,curAnim=null;
const sleep=async(ms,id)=>{for(let w=0;w<ms&&id===runId;w+=40)await wait(Math.min(40,ms-w))};
/* haltNow: hentikan semua animasi/urutan saat itu juga (langkah yang sedang jalan langsung diselesaikan) */
function haltNow(){auto=false;mauto=false;runId++;if(curAnim)curAnim();const a=$('#pa');if(a)a.textContent='▶ Putar otomatis'}
async function halt(){haltNow();for(let n=0;busy&&n<150;n++)await wait(10);busy=false}
function play(t,inv,dur){dur=dur||spd.dur;const q=tok(t);let k=inv?-q.k:q.k;if(k===-2)k=2;const[ax,ls,ph]=MD[q.n],phi=ph*90*k,th=ax===1?phi:-phi,fn=['rotateX','rotateY','rotateZ'][ax],els=[...document.querySelectorAll('.sk')].filter(e=>ls.includes(SL[e.dataset.i].c[ax]));
els.forEach(e=>{e.style.transition='none';e.style.transform=`${fn}(0deg) ${BT(e.dataset.i)}`});void document.body.offsetWidth;
els.forEach(e=>{e.style.transition=`transform ${dur}ms ease-in-out`;e.style.transform=`${fn}(${th}deg) ${BT(e.dataset.i)}`});
return new Promise(r=>{let done=false,tm=0;const end=()=>{if(done)return;done=true;clearTimeout(tm);if(curAnim===end)curAnim=null;S=ap(S,TP(q.n,k));els.forEach(e=>{e.style.transition='none';e.style.transform=BT(e.dataset.i)});paintAll();void document.body.offsetWidth;els.forEach(e=>e.style.transition='');r()};curAnim=end;tm=setTimeout(end,dur+10)})}
async function runSeq(a,inv,gap,dur,on){gap=gap==null?spd.gap:gap;dur=dur||spd.dur;const id=runId;busy=true;
for(let i=0;i<a.length&&id===runId;i++){if(on)on(i,a[i]);await play(a[i],inv,dur);if(i<a.length-1)await sleep(gap,id)}
busy=false}
function curHtml(){if(!SOL.length)return '';if(pi>=SOL.length)return '<p style="font-weight:600;margin:8px 0">Selesai ✓ Kubus sudah rapi.</p>';const t=SOL[pi];return `<div class="cw">${moveArt(t,96)}<div><b>Berikutnya: ${fm(t)}</b><span>${fm(desc(t))}.</span></div></div>`}
const tiles=(arr,pos)=>arr.map((t,i)=>`<span class="ch ${i<pos?'d':i===pos?'n':''}">${moveArt(t,36)}<b>${fm(t)}</b></span>`).join('');
function chips(){const c=$('#cur');if(c)c.innerHTML=curHtml();const o=$('#sol');if(o)o.innerHTML=tiles(SOL,pi)}
function clr(){SOL=[];pi=0;auto=false;chips();const a=$('#pa');if(a)a.textContent='▶ Putar otomatis'}
async function fwd(){if(busy||pi>=SOL.length)return false;await runSeq([SOL[pi]]);pi++;chips();return true}
async function back(){if(busy||pi<=0)return;pi--;await runSeq([SOL[pi]],true);chips()}
function expand(t){let p;do{p=t;t=t.replace(/\(([^()]*)\)\s*(\d+)/g,(_,a,n)=>(a+' ').repeat(+n))}while(t!==p);return t.replace(/[()]/g,' ').trim().split(/\s+/).filter(Boolean)}
document.addEventListener('pointerdown',e=>{const st=e.target.closest('#stg,#stg2,#stg3');if(st&&(st.id!=='stg'||mode==='res')){drag=true;moved=false;sx=e.clientX;sy=e.clientY}});
addEventListener('pointermove',e=>{if(!drag)return;const dx=e.clientX-sx,dy=e.clientY-sy;if(Math.hypot(dx,dy)>3)moved=true;if(moved){ry+=dx*.5;rx=Math.max(-85,Math.min(85,rx-dy*.5));sx=e.clientX;sy=e.clientY;view()}});
addEventListener('pointerup',()=>{drag=false});

function afterAuth(){loadDone();if(run){cancelAnimationFrame(raf);run=false}location.hash='akun';render()}
addEventListener('hashchange',render);render();
