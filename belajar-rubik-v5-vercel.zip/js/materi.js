/* Materi belajar: kategori, daftar bab, dan rumus */
const C={y:'var(--y)',g:'var(--g)',b:'var(--b)',o:'var(--o)',r:'var(--r)'};
const L=[
{id:'notasi',g:'Dasar',t:'Notasi & dasar kubus',c:'y',x:[
{h:'Putaran sisi: F, B, U, D, R, L',p:'Setiap huruf adalah satu sisi, dan arah putarnya dilihat saat kamu menghadap sisi itu langsung. Tanpa tanda berarti searah jarum jam, tanda ’ berarti berlawanan, dan angka 2 berarti 180°.',a:[
{n:'F (depan)',a:"F F' F2",d:'F memutar sisi depan 90° searah jarum jam. F’ kebalikannya. F2 putar 180°.'},
{n:'B (belakang)',a:"B B' B2",d:'Searah jarum jam dilihat dari belakang, jadi dari depan terlihat berlawanan arah.'},
{n:'U (atas)',a:"U U' U2",d:'Dilihat dari atas. Dari depan, lapisan atas bergerak ke kiri.'},
{n:'D (bawah)',a:"D D' D2",d:'Dilihat dari bawah. Dari depan, lapisan bawah bergerak ke kanan.'},
{n:'R (kanan)',a:"R R' R2",d:'Sisi depan naik ke atas saat R dilakukan.'},
{n:'L (kiri)',a:"L L' L2",d:'Sisi depan turun ke bawah saat L dilakukan.'}]},
{h:'Lapisan tengah: M, E, S',p:'Tiga lapisan yang tidak punya sisi luar. Arahnya mengikuti salah satu sisi.',a:[
{n:'M (tengah kiri-kanan)',a:"M M' M2",d:'Arahnya seperti L: sisi depan turun.'},
{n:'E (tengah atas-bawah)',a:"E E' E2",d:'Arahnya seperti D: sisi depan bergerak ke kanan.'},
{n:'S (tengah depan-belakang)',a:"S S' S2",d:'Arahnya seperti F.'}]},
{h:'Putar dua lapis: r, l, u, d, f, b',p:'Huruf kecil (atau huruf besar dengan w, misalnya Rw) memutar sisi itu bersama lapisan tengah di sebelahnya.',a:[
{n:'r atau Rw',a:"r r' r2",d:'Sama dengan R lalu M’. Dua lapis kanan berputar bersama.'},
{n:'l atau Lw',a:"l l' l2",d:'Sama dengan L lalu M.'},
{n:'u atau Uw',a:"u u' u2",d:'Sama dengan U lalu E’.'},
{n:'d atau Dw',a:"d d' d2",d:'Sama dengan D lalu E.'},
{n:'f atau Fw',a:"f f' f2",d:'Sama dengan F lalu S.'},
{n:'b atau Bw',a:"b b' b2",d:'Sama dengan B lalu S’.'}]},
{h:'Memutar seluruh kubus: x, y, z',p:'Seluruh kubus diputar, tidak ada lapisan yang berubah relatif satu sama lain. Dipakai untuk mengganti sisi yang menghadap.',a:[
{n:'x',a:"x x' x2",d:'Putar seluruh kubus searah R. Sisi depan jadi atas.'},
{n:'y',a:"y y' y2",d:'Putar seluruh kubus searah U. Sisi depan jadi kiri. Paling sering dipakai di F2L.'},
{n:'z',a:"z z' z2",d:'Putar seluruh kubus searah F. Sisi atas jadi kanan.'}]},
{h:'Tanda lain',p:'Beberapa penulisan yang sering ketemu di buku atau video tutorial. Semua notasi di atas bisa dicoba langsung di halaman Solver 3D lewat kolom Coba rumus.',a:[
{n:'Prime ditulis i',a:"Ri Ui Fi",d:'Gaya lama. Ri sama dengan R’, Ui sama dengan U’.'},
{n:'Angka 2 dan prime',a:"R2'",d:'R2’ sama saja dengan R2.'},
{n:'Kurung dan pengulangan',a:"(R U R' U')3",d:'Isi kurung diulang sebanyak angka di belakangnya. Di sini sexy move diulang 3 kali.'}]}
],
p:['Satu huruf berarti memutar satu sisi 90° searah jarum jam (dilihat dari sisi itu). Tanda ’ (prime) berarti berlawanan arah jarum jam, dan angka 2 berarti putar 180°.','Nama sisi: U (atas), D (bawah), R (kanan), L (kiri), F (depan), B (belakang). Huruf kecil seperti r atau u berarti memutar dua lapisan sekaligus. M, E, S memutar lapisan tengah. x, y, z memutar seluruh kubus.','Pusat tiap sisi tidak pernah berpindah, jadi warnanya jadi patokan. Skema standar: putih lawan kuning, merah lawan oranye, biru lawan hijau. Kubus 3×3 punya 6 pusat, 12 edge (dua warna), dan 8 corner (tiga warna).'],
a:[{n:'Contoh notasi',a:"R U R' U'",d:'Kanan searah, atas searah, kanan berlawanan, atas berlawanan. Urutan ini disebut “sexy move” dan dipakai di banyak rumus.'},{n:'Putar 180°',a:'R2 U2',d:'Arah putar tidak penting karena 180° sama saja ke dua arah.'}]},
{id:'pemula',g:'Metode pemula',t:'Layer demi layer',c:'g',
p:['Cara paling mudah untuk menyelesaikan kubus pertama kali. Selesaikan satu lapisan, lalu lapisan berikutnya. Contoh di sini memakai putih di bawah dan kuning di atas.'],
s:['Cross putih: buat tanda plus putih di sisi bawah, lalu cocokkan warna sampingnya dengan pusat.','Corner putih: letakkan corner putih di atas slot tujuannya, lalu ulangi rumus di bawah sampai masuk.','Edge lapisan tengah: cari edge di sisi atas yang tidak berwarna kuning, lalu masukkan ke kiri atau ke kanan.','Cross kuning: buat plus kuning di sisi atas dengan rumus F R U R’ U’ F’ (ulangi sesuai bentuk: titik, L, atau garis).','Posisikan edge kuning supaya cocok dengan pusat sisi samping.','Posisikan corner kuning ke tempat yang benar, lalu putar masing-masing sampai kuning menghadap atas.'],
a:[{n:'Corner putih',a:"R U R' U'",d:'Ulangi 1 sampai 5 kali sampai corner masuk dengan putih menghadap bawah.'},{n:'Edge ke kanan',a:"U R U' R' U' F' U F",d:'Edge di depan yang harus pindah ke slot kanan.'},{n:'Edge ke kiri',a:"U' L' U L U F U' F'",d:'Edge di depan yang harus pindah ke slot kiri.'},{n:'Cross kuning',a:"F R U R' U' F'",d:'Dari bentuk garis, pegang garis horizontal. Dari bentuk L, pegang L di kiri atas belakang. Dari titik, lakukan sekali, lalu ulangi sesuai bentuk baru.'},{n:'Posisi edge kuning',a:"R U R' U R U2 R' U",d:'Ulangi sampai dua edge cocok, lalu putar U sampai semuanya cocok.'},{n:'Posisi corner kuning',a:"U R U' L' U R' U' L",d:'Ulangi sampai tiap corner berada di tempat yang benar, orientasinya boleh salah dulu.'},{n:'Putar corner',a:"R' D' R D",d:'Ulangi 2 atau 4 kali per corner sampai kuning menghadap atas. Jangan putar kubus selama satu corner, putar U saja untuk pindah ke corner berikutnya.'}],
tip:'Saat memutar corner terakhir, kubus akan terlihat berantakan di tengah proses. Itu normal, tetap lanjut sampai corner itu selesai.'},
{id:'cfop',g:'CFOP',t:'Pengantar CFOP',c:'b',
p:['CFOP (Fridrich) adalah metode yang dipakai kebanyakan speedcuber. Idenya sama seperti layer demi layer, tapi lebih efisien karena menyelesaikan dua lapisan pertama sekaligus.','Empat tahap: Cross, F2L (First Two Layers), OLL (Orient Last Layer), dan PLL (Permute Last Layer).'],
s:['Cross: buat plus di sisi bawah dalam 8 gerakan atau kurang.','F2L: masukkan pasangan corner dan edge ke empat slot, sehingga dua lapisan pertama selesai.','OLL: buat seluruh sisi atas satu warna. Versi 2-look hanya butuh 10 rumus.','PLL: pindahkan pieces lapisan terakhir ke posisi yang benar. Versi 2-look hanya butuh 6 rumus.'],
tip:'Mulai dari 2-look OLL dan 2-look PLL. Total hanya 16 rumus dan sudah bisa dapat waktu di bawah 40 detik.'},
{id:'cross',g:'CFOP',t:'Cross',c:'b',
p:['Cross adalah empat edge di sekitar satu pusat (biasanya putih) yang sudah cocok dengan pusat samping. Hampir semua dilakukan secara intuitif tanpa rumus hafalan.'],
s:['Selama waktu inspeksi 15 detik, cari keempat edge putih dan rencanakan urutannya.','Taruh cross di bawah supaya bisa langsung lanjut ke F2L tanpa memutar kubus.','Selesaikan satu edge per langkah dan jangan merusak edge yang sudah benar.','Latih sampai bisa merencanakan semua edge sebelum mulai memutar.'],
a:[{n:'Edge putih di atas',a:'F2',d:'Edge putih di sisi atas dengan warna depan sama dengan pusat depan, putar F2 langsung masuk ke bawah.'}],
tip:'Putar sisi bawah (D) untuk mencocokkan edge dengan pusat sampingnya tanpa merusak edge lain yang sudah masuk.'},
{id:'f2l',g:'CFOP',t:'F2L',c:'o',
p:['F2L menyelesaikan dua lapisan pertama sekaligus dengan memasangkan corner dan edge, lalu memasukkannya ke slot yang kosong. Ada 41 kasus, tapi semuanya variasi dari beberapa pola dasar.','Cara berpikir: 1) cari pasangan corner dan edge yang cocok, 2) bawa keduanya ke atas slot, 3) satukan jadi satu pasangan, 4) masukkan ke slot.'],
a:[{n:'Masukkan pasangan (kanan)',a:"U R U' R'",d:'Pola dasar: pasangan sudah menyatu di atas, masuk ke slot kanan depan.'},{n:'Masukkan pasangan (kiri)',a:"U' L' U L",d:'Cermin dari pola kanan, untuk slot kiri depan.'},{n:'Pemisah pasangan',a:"R U R' U'",d:'Sexy move juga dipakai untuk membongkar atau menyatukan corner dan edge saat keduanya belum berpasangan. Coba, lihat hasilnya, lalu lanjut.'}],
tip:'Jangan hafal semua 41 kasus sekaligus. Cari satu pola, latih sampai lancar, lalu tambah kasus berikutnya. Putar kubus (y) agar slot kosong selalu di kanan depan.'},
{id:'oll',g:'CFOP',t:'OLL (2-look)',c:'y',
p:['OLL membuat seluruh sisi atas satu warna (kuning). Versi 2-look melakukannya dalam dua langkah: buat cross kuning dulu, lalu orientasikan corner.','Langkah 1: cross kuning. Bentuk yang terlihat: titik, L, atau garis.'],
a:[{n:'Garis',a:"F R U R' U' F'",d:'Pegang garis horizontal.'},{n:'L',a:"F U R U' R' F'",d:'Pegang L di kiri atas belakang.'},{n:'Titik',a:"F R U R' U' F' lalu F U R U' R' F'",d:'Lakukan rumus garis dulu, lalu rumus L, sampai cross jadi.'},{n:'Sune',a:"R U R' U R U2 R'",d:'Corner: satu corner sudah kuning di atas. Pegang kuning di depan kiri bawah.'},{n:'Anti-Sune',a:"R U2 R' U' R U' R'",d:'Corner: satu corner sudah kuning di atas. Kuning menghadap kanan depan.'},{n:'H',a:"F R U R' U' R U R' U' R U R' U' F'",d:'Semua corner menghadap samping, dua sisi berlawanan kuning.'},{n:'Pi',a:"R U2 R2 U' R2 U' R2 U2 R",d:'Semua corner menghadap samping, kuning di dua corner yang bersebelahan.'},{n:'U',a:"R2 D R' U2 R D' R' U2 R'",d:'Dua corner sudah kuning di atas dan dua lagi menghadap depan.'},{n:'T',a:"r U R' U' r' F R F'",d:'Dua corner sudah kuning, dua corner menghadap kiri dan kanan.'},{n:'L',a:"F R' F' r U R U' r'",d:'Dua corner sudah kuning di atas, bentuk L.'}],
tip:'Untuk corner, hampir selalu bisa dikenali dari jumlah corner yang sudah kuning: 0 (H atau Pi), 1 (Sune atau Anti-Sune), 2 (U, T, atau L).'},
{id:'pll',g:'CFOP',t:'PLL',c:'r',
p:['PLL memindahkan pieces lapisan terakhir ke tempat yang benar tanpa merusak orientasi. Versi 2-look: pindahkan corner dulu, lalu edge.','Untuk corner, cari “headlights” (dua corner di satu sisi dengan warna sama). Kalau ada, pakai A-perm. Kalau tidak ada, pakai Y-perm.'],
a:[{n:'Corner: A-perm (Aa)',a:"x R' U R' D2 R U' R' D2 R2",d:'Pegang headlights di belakang.'},{n:'Corner: Y-perm',a:"F R U' R' U' R U R' F' R U R' U' R' F R F'",d:'Dipakai saat tidak ada headlights.'},{n:'Edge: U-perm (Ua)',a:"R U' R U R U R U' R' U' R2",d:'Tiga edge berputar ke arah satu sisi. Pegang edge yang sudah benar di belakang.'},{n:'Edge: U-perm (Ub)',a:"R2 U R U R' U' R' U' R' U R'",d:'Tiga edge berputar ke arah sebaliknya.'},{n:'Edge: H-perm',a:'M2 U M2 U2 M2 U M2',d:'Dua pasang edge saling tukar di sisi berlawanan.'},{n:'Edge: Z-perm',a:"M' U M2 U M2 U M' U2 M2",d:'Dua pasang edge saling tukar di sisi bersebelahan.'},{n:'T-perm (full PLL)',a:"R U R' U' R' F R2 U' R' U' R U R' F'",d:'Menukar dua corner dan dua edge. Rumus favorit karena mudah dilatih.'},{n:'J-perm (Jb)',a:"R U R' F' R U R' U' R' F R2 U' R'",d:'Menukar dua corner dan dua edge yang bersebelahan.'}],
tip:'Latih tiap rumus perlahan dulu. Kecepatan datang sendiri setelah tangan hafal urutannya, jangan buru-buru.'},
{id:'solver',g:'Solver 3D',t:'Solver 3D',c:'o',tool:2,p:['Isi warna kubus aslimu sisi demi sisi, tanpa perlu memutar kubus di layar. Kubus 3D akan berputar sendiri ke sisi berikutnya setiap kamu menekan tombol >. Setelah semua terisi, tekan Selesaikan untuk mendapat langkah-langkahnya dalam huruf notasi.']},
{id:'magic',g:'Magic',t:'Sulap Cube (Magic)',c:'r',tool:3,p:['Sulap cube punya dua mode. Jelajah magic: urutan gerakan yang kalau diulang terus akan membuat kubus kembali normal, dikelompokkan Easy, Normal, dan Hard menurut banyaknya gerakan. Tantangan sulap: permainan tiga fase (Easy 4 gerakan, Normal 8, Hard 14) di mana kubus diacak dengan “sulap” dan kamu harus mengembalikannya.']},
{id:'latihan',g:'Latihan',t:'Acak & timer',c:'g',tool:1,
p:['Ketuk tombol atau tekan spasi untuk memulai timer. Tekan lagi untuk berhenti. Pegang kubus dengan putih di atas dan hijau di depan sebelum mengikuti acakan. Acakan dan semua waktumu tersimpan otomatis di perangkat ini.']},
{id:'tips',g:'Latihan',t:'Tips belajar',c:'b',
s:['Latih satu hal sampai lancar sebelum lanjut. Kubus pertama selesai dulu, baru CFOP.','Pelajari rumus sebagai pola jari, bukan huruf satu per satu. Ucapkan “sexy move”, “sledgehammer”, dsb. agar mudah diingat.','Lihat arah gerakan sebelum memutar. Banyak kesalahan terjadi karena salah arah.','Latih tangan kiri dan kanan seimbang supaya rumus mirror juga lancar.','Pakai kubus yang halus dan sedikit dilumasi. Kubus seret membuat belajar jadi menyebalkan.','Istirahat teratur. Tangan dan otak sama-sama butuh waktu untuk menyimpan pola.']}
];



