/* ===== Akun: halaman Masuk, Daftar, dan Akun =====
   Kata sandi dan lockout diperiksa di server (api/*.js). Sesi di perangkat hanya menyimpan nama.
   Riwayat belajar (timer, materi, sulap) tetap disimpan per akun di perangkat ini. */
const USESI='rubik-sesi',NAMA_RE=/^[a-z0-9_]{3,20}$/;
const AUTH_PAGES=['masuk','daftar','akun'];
const readJ=k=>{try{return JSON.parse(localStorage.getItem(k)||'null')}catch(e){return null}};
const me=()=>{try{return localStorage.getItem(USESI)||null}catch(e){return null}};
/* Kunci penyimpanan: tamu memakai kunci biasa, akun memakai kunci + ":nama" */
const ukey=base=>{const n=me();return n?base+':'+n:base};
async function api(path,body){
 try{
  const r=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  let j={};try{j=await r.json()}catch(e){}
  return {ok:r.ok,status:r.status,data:j};
 }catch(e){return {ok:false,status:0,data:{error:'Tidak bisa terhubung ke server. Coba lagi.'}}}
}
const sesiSimpan=n=>localStorage.setItem(USESI,n);
async function daftarAkun(n,pw){const r=await api('/api/register',{n,pw});if(!r.ok)return r.data.error||'Gagal membuat akun.';sesiSimpan(n);afterAuth();return null}
async function loginAkun(n,pw){const r=await api('/api/login',{n,pw});if(!r.ok)return r.data.error||'Gagal masuk.';sesiSimpan(n);afterAuth();return null}
function keluarAkun(){localStorage.removeItem(USESI);afterAuth()}
async function hapusAkun(pw){
 const n=me();if(!n)return 'Kamu belum masuk.';
 const r=await api('/api/hapus',{n,pw});if(!r.ok)return r.data.error||'Gagal menghapus akun.';
 ['rubik-done','rubik-timer','rubik-sulap'].forEach(k=>localStorage.removeItem(k+':'+n));
 localStorage.removeItem(USESI);afterAuth();return null;
}
/* Kotak status akun di menu samping */
function akunBox(){const n=me();
 return n?`<a class="akbox" href="#akun"><span>👤</span><b>${n}</b><small>Akun</small></a>`
  :`<div class="akbox"><span>Belum masuk</span><div><a class="btn alt xs" href="#masuk">Masuk</a><a class="btn xs" href="#daftar">Daftar</a></div></div>`};
/* Catatan di atas riwayat timer */
function riwayatNote(){const n=me();
 return `<p class="rn">${n?`Riwayat ini tersimpan di akun <b>${n}</b> di perangkat ini.`:'Kamu belum masuk, jadi riwayat disimpan sebagai tamu di perangkat ini. <a href="#masuk">Masuk</a> atau <a href="#daftar">daftar</a> agar riwayat terikat ke akunmu.'} Setiap kali berhenti, waktu masuk ke daftar bersama acakannya. Pakai +2 atau DNF kalau perlu.</p>`};
/* Helper form */
const aerr=(id,t)=>{const e=document.getElementById(id);if(e)e.textContent=t};
const tahanTombol=(b,label)=>{const t=b.textContent;b.disabled=true;b.textContent=label;return()=>{b.disabled=false;b.textContent=t}};
async function kirim(b,label,errId,fn){
 aerr(errId,'');const pulih=tahanTombol(b,label);
 try{const err=await fn();if(err){aerr(errId,err);pulih()}}
 catch(x){aerr(errId,'Terjadi kesalahan. Coba lagi.');pulih()}
}
const pwField=(id,ac)=>`<span class="pw"><input id="${id}" type="password" autocomplete="${ac}" required><button type="button" class="btn alt xs" data-pv="${id}">Lihat</button></span>`;
/* ===== Halaman terpisah: Masuk ===== */
function halamanMasuk(){return `<div class="auth"><h1>Masuk</h1><p class="lead">Masuk untuk menyimpan riwayat timer, progres materi, dan rekor sulap di akunmu.</p>
<form class="af" id="fa" novalidate>
 <div class="fl"><label for="ma">Nama pengguna</label><input id="ma" autocomplete="username" autocapitalize="off" autocorrect="off" spellcheck="false" maxlength="20" required></div>
 <div class="fl"><label for="mp">Kata sandi</label>${pwField('mp','current-password')}</div>
 <p class="aerr" id="mx" role="alert"></p><button class="btn" id="mb" type="submit">Masuk</button>
</form><p class="asw">Belum punya akun? <a href="#daftar"><b>Daftar di sini</b></a></p></div>`}
/* ===== Halaman terpisah: Daftar ===== */
function halamanDaftar(){return `<div class="auth"><h1>Daftar</h1><p class="lead">Buat akun baru. Riwayat timer dan progres belajarmu akan tersimpan di akun ini.</p>
<form class="af" id="fd" novalidate>
 <div class="fl"><label for="du">Nama pengguna</label><input id="du" autocomplete="username" autocapitalize="off" autocorrect="off" spellcheck="false" maxlength="20" required><small>3–20 karakter: huruf kecil, angka, atau garis bawah.</small></div>
 <div class="fl"><label for="dp">Kata sandi</label>${pwField('dp','new-password')}<small>Minimal 6 karakter.</small></div>
 <div class="fl"><label for="dq">Ulangi kata sandi</label><input id="dq" type="password" autocomplete="new-password" required></div>
 <p class="aerr" id="dx" role="alert"></p><button class="btn" id="db" type="submit">Buat akun</button>
</form><p class="asw">Sudah punya akun? <a href="#masuk"><b>Masuk di sini</b></a></p></div>`}
/* ===== Halaman Akun (ringkasan, keluar, hapus) ===== */
function halamanAkun(){const n=me();
 if(!n)return `<div class="auth"><h1>Akun</h1><p class="lead">Kamu belum masuk. Masuk untuk menyimpan progres dan riwayat timer per akun.</p><div class="row" style="justify-content:flex-start"><a class="btn" href="#masuk">Masuk</a><a class="btn alt" href="#daftar">Daftar</a></div></div>`;
 const sel=readJ('rubik-done:'+n)||{},jm=Object.keys(sel).filter(k=>sel[k]&&L.some(l=>l.id===k)).length;
 const tm=((readJ('rubik-timer:'+n)||{}).list||[]).length;
 const sul=readJ('rubik-sulap:'+n)||{};
 const menang=['easy','normal','hard'].reduce((a,k)=>a+((sul[k]&&sul[k].wins)||0),0);
 return `<div class="auth wide"><h1>Akun</h1><p class="lead">Masuk sebagai <b>${n}</b>. Progres belajarmu tersimpan di akun ini.</p>
 <div class="tst"><div><small>Materi ditandai selesai</small><b>${jm}/${L.length}</b></div><div><small>Waktu tersimpan</small><b>${tm}</b></div><div><small>Sulap menang</small><b>${menang}</b></div></div>
 <h2>Keluar</h2><div class="row" style="justify-content:flex-start"><button class="btn" id="akun-keluar">Keluar</button></div>
 <h2>Hapus akun</h2>
 <div class="fl"><label for="ax">Kata sandi untuk konfirmasi</label><input id="ax" type="password" autocomplete="current-password"></div>
 <p class="aerr" id="axe" role="alert"></p>
 <div class="row" style="justify-content:flex-start"><button class="btn alt" id="akun-hapus">Hapus akun</button></div>
 <p class="asw">Menghapus akun akan menghapus akun di server dan semua data belajarmu di perangkat ini. Tidak bisa dibatalkan.</p></div>`}
function halamanAuth(p){return p==='masuk'?halamanMasuk():p==='daftar'?halamanDaftar():halamanAkun()}
/* Pasang perilaku setiap halaman akun */
function bindAuth(p){
 document.querySelectorAll('[data-pv]').forEach(b=>b.onclick=()=>{const i=document.getElementById(b.dataset.pv);const show=i.type==='password';i.type=show?'text':'password';b.textContent=show?'Sembunyikan':'Lihat'});
 if(p==='masuk')$('#fa').onsubmit=e=>{e.preventDefault();const n=$('#ma').value.trim().toLowerCase(),pw=$('#mp').value;
  if(!n||!pw)return aerr('mx','Isi nama pengguna dan kata sandi.');
  kirim($('#mb'),'Memeriksa…','mx',()=>loginAkun(n,pw))};
 if(p==='daftar')$('#fd').onsubmit=e=>{e.preventDefault();const n=$('#du').value.trim().toLowerCase(),pw=$('#dp').value,pw2=$('#dq').value;
  const err=!NAMA_RE.test(n)?'Nama pengguna 3–20 karakter: huruf kecil, angka, atau garis bawah.':pw.length<6?'Kata sandi minimal 6 karakter.':pw!==pw2?'Ulangi kata sandi belum sama.':'';
  if(err)return aerr('dx',err);
  kirim($('#db'),'Membuat akun…','dx',()=>daftarAkun(n,pw))};
 if(p==='akun'){
  const k=$('#akun-keluar');if(k)k.onclick=keluarAkun;
  const h=$('#akun-hapus');if(h)h.onclick=()=>{const pw=$('#ax').value;
   if(!pw)return aerr('axe','Masukkan kata sandi untuk menghapus akun.');
   if(!confirm('Hapus akun ini beserta semua datanya? Tidak bisa dibatalkan.'))return;
   kirim(h,'Menghapus…','axe',()=>hapusAkun(pw))};
 }
}
