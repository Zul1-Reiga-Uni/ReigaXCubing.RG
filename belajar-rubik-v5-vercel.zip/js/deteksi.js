/* Deteksi kesalahan: isian sisi kubus, notasi rumus, dan hasil solver */
const NM_W={W:'putih',Y:'kuning',R:'merah',O:'oranye',B:'biru',G:'hijau'};
const NM_S={U:'Atas',D:'Bawah',R:'Kanan',L:'Kiri',F:'Depan',B:'Belakang'};

/* Periksa isian 54 stiker. Mengembalikan daftar masalah; kosong berarti isian valid.
   Setiap masalah: { tipe, pesan, sel (indeks stiker yang salah), sisi (huruf sisi untuk ditunjuk) } */
function periksaIsian(s){
 const out=[];
 const add=(tipe,pesan,sel)=>{sel=sel||[];out.push({tipe,pesan,sel,sisi:sel.length?SL[sel[0]].f:null})};
 const kosong=[];s.forEach((c,i)=>{if(c==='N')kosong.push(i)});
 if(kosong.length){add('kosong',`Masih ada ${kosong.length} kotak yang belum diisi.`,kosong);return out}

 /* 1. Jumlah tiap warna harus 9 */
 const n={};s.forEach(c=>{n[c]=(n[c]||0)+1});
 for(const c of 'WYROBG'){const k=n[c]||0;
  if(k!==9)add('jumlah',`Warna ${NM_W[c]} ada ${k} kotak, seharusnya 9.`,k>9?s.reduce((a,x,i)=>{if(x===c)a.push(i);return a},[]):[])}
 if(out.length)return out;

 /* 2. Enam pusat sisi harus beda warna */
 const ctr=Object.values(CI);
 for(let a=0;a<ctr.length;a++)for(let b=a+1;b<ctr.length;b++)
  if(s[ctr[a]]===s[ctr[b]])add('pusat',`Pusat sisi ${NM_S[SL[ctr[a]].f]} dan ${NM_S[SL[ctr[b]].f]} sama-sama ${NM_W[s[ctr[a]]]}. Setiap pusat harus beda warna.`,[ctr[a],ctr[b]]);
 if(out.length)return out;

 /* 3. Setiap sudut dan rusuk harus berupa kombinasi warna yang ada di kubus asli */
 const cc=i=>s[CI[SL[i].f]];
 const cari=(P,p)=>{const cols=P[p].map(i=>s[i]);
  for(let h=0;h<P.length;h++){const hc=P[h].map(cc);
   if(hc.every(c=>cols.includes(c))&&cols.every(c=>hc.includes(c)))return{h,o:cols.indexOf(cc(P[h][0]))}}
  return null};
 const nama=P=>P.map(i=>NM_S[SL[i].f]).join(' · ');
 const warna=P=>P.map(i=>NM_W[s[i]]).join(', ');
 const cekPotongan=(P,hasil,jenis,jamak)=>{
  const rusak=[];hasil.forEach((r,p)=>{if(!r)rusak.push(p)});
  rusak.forEach(p=>add('potongan',`${jenis} ${nama(P[p])} punya kombinasi warna yang tidak ada di kubus (${warna(P[p])}). Cek stiker di tempat ini.`,P[p]));
  if(rusak.length)return;
  const seen={};hasil.forEach((r,p)=>{if(seen[r.h]!==undefined){const q=seen[r.h];
   add('duplikat',`${jenis} ${nama(P[q])} dan ${nama(P[p])} terbaca sama. ${jamak} ini tidak boleh sama, cek warna stiker di kedua tempat.`,[...P[q],...P[p]])}
   else seen[r.h]=p})};
 const kor=CORN.map((P,p)=>cari(CORN,p)), tep=EDGE.map((P,p)=>cari(EDGE,p));
 cekPotongan(CORN,kor,'Sudut','Sudut');
 if(out.length)return out;
 cekPotongan(EDGE,tep,'Rusuk','Rusuk');
 if(out.length)return out;

 /* 4. Orientasi sudut: jumlah putaran harus kelipatan 3 */
 const twSum=kor.reduce((a,r)=>a+r.o,0);
 if(twSum%3){const hit=[];kor.forEach((r,p)=>{if(r.o)hit.push(p)});
  add('putar',`Ada ${hit.length} sudut yang terpuntir. Biasanya satu sudut terpasang dengan arah yang salah. Cek stiker di sudut yang disorot.`,hit.reduce((a,p)=>a.concat(CORN[p]),[]))}

 /* 5. Orientasi rusuk: jumlah balikan harus genap */
 const eoSum=tep.reduce((a,r)=>a+r.o,0);
 if(eoSum%2){const hit=[];tep.forEach((r,p)=>{if(r.o)hit.push(p)});
  add('balik',`Ada ${hit.length} rusuk yang terbalik. Biasanya dua stiker di satu rusuk tertukar. Cek rusuk yang disorot.`,hit.reduce((a,p)=>a.concat(EDGE[p]),[]))}

 /* 6. Paritas: posisi sudut dan rusuk harus sama-sama genap atau sama-sama ganjil */
 if(par(kor.map(r=>r.h))!==par(tep.map(r=>r.h)))
  add('paritas','Ada dua bagian yang tertukar posisinya. Biasanya dua rusuk atau dua sudut tertukar. Cek ulang warna di tiap sisi.');
 return out;
}

/* Periksa notasi rumus. Mengembalikan {ok, pesan, teks} */
function periksaRumus(raw){
 const t=(raw||'').replace(/[’‘`´]/g,"'").trim();
 if(!t)return{ok:false,pesan:"Tulis rumus dulu, misalnya R U R' U'."};
 const buka=(t.match(/\(/g)||[]).length,tutup=(t.match(/\)/g)||[]).length;
 if(buka!==tutup)return{ok:false,pesan:buka>tutup?'Ada kurung “(” yang belum ditutup “)”.':'Ada kurung “)” tanpa pasangan “(”.'};
 const bersih=t.replace(/\(\s*\)/g,' ').replace(/\)\s*\d+/g,')').replace(/[()]/g,' ').trim();
 for(const x of bersih.split(/\s+/)){
  if(!x||tok(x))continue;
  if(/^(?:[RLUDFBrludfbMESxyz]w?(?:2|'|i)?)+$/.test(x)&&x.length>1)
   return{ok:false,pesan:`Gerakan “${x}” menempel jadi satu. Beri spasi di antara gerakan, misalnya R U R' U'.`};
  const kand=[x.replace(/i$/,"'"),x.replace(/3$/,"'"),x.replace(/[’‘`´]/g,"'"),x.replace(/^(.)/,c=>c.toUpperCase()),x.toUpperCase()];
  const sar=kand.find(k=>k!==x&&tok(k));
  return{ok:false,pesan:`Notasi “${x}” tidak dikenali.`+(sar?` Mungkin maksudnya “${sar}”.`:' Gerakan yang dikenal: R L U D F B M E S x y z, dan r l u d f b.')}
 }
 return{ok:true,pesan:'',teks:t};
}

/* Pastikan hasil solver benar-benar menyelesaikan kubus. Dipanggil sebelum hasil ditampilkan. */
function cekSolusi(s,r){
 let e=s.slice();
 for(const m of r){const q=tok(m);if(!q)return false;e=ap(e,TP(q.n,q.k))}
 const h=home();return e.every((c,i)=>c===h[i]);
}

/* Apakah kubus sudah dalam keadaan rapi */
const isRapi=s=>{const h=home();return s.every((c,i)=>c===h[i])};
