/* Daftar posisi edge sama seperti solver.js (EDGE), dibaca ulang dari kode sumber. */
module.exports=function(H){const src=require('fs').readFileSync(require('path').join(__dirname,'..','js/solver.js'),'utf8');return new Function(src+';return EDGE')()};
