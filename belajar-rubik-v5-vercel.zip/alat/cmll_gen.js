const H=require('./hz.js'),{SL,IX,CI,tok,TP,seqP,ap,ID}=H;
const P=n=>seqP(n),lab0=SL.map((_,i)=>i);
const cub=SL.map(s=>s.c);
const tracked=i=>{const c=SL[i].c;return (Math.abs(c[0])===1&&c[1]<=0)||(Math.abs(c[0])===1&&c[1]===1&&Math.abs(c[2])===1)};
const mk=a=>a.map(l=>tracked(l)?l:-1),G=mk(lab0);
const mv=names=>{const o=[];for(const X of names)o.push({n:X,p:P(X)},{n:X+'2',p:P(X+'2')},{n:X+"'",p:P(X+"'")});return o};
const macs=["U","U'","U2","R U R' U R U2 R'","R U2 R' U' R U' R'","R U R' U' R' F R2 U' R' U' R U R' F'","R' F R' B2 R F' R' B2 R2","R U R' F' R U R' U' R' F R2 U' R'"].map(n=>[n,P(n)]);
const seen=new Map([[G.join(),G]]);let fr=[G];
while(fr.length){const nx=[];for(const s of fr)for(const [n,p] of macs){const t=ap(s,p),k=t.join();if(!seen.has(k)){seen.set(k,t);nx.push(t)}}fr=nx}
console.log('keadaan sudut',seen.size);
const Ua=[ID,P('U'),P('U2'),P("U'")],invp=p=>{const q=[];p.forEach((v,i)=>q[v]=i);return q};
const canon=s=>{let b=null;for(const a of Ua){const ia=invp(a);const r=s.map(l=>l<0?-1:(SL[l].c[1]===1?ia[l]:l));for(const bb of Ua){const t=ap(r,bb),k=t.join();if(b===null||k<b)b=k}}return b};
const cls=new Map();for(const s of seen.values()){const k=canon(s);if(!cls.has(k))cls.set(k,s)}
console.log('kelas',cls.size);
function search(rep,moves,maxd){const pinv=moves.map(m=>({n:m.n,i:moves.find(x=>x.n===(m.n.endsWith("'")?m.n.slice(0,-1):m.n.endsWith('2')?m.n:m.n+"'")).p}));
 if(rep.join()===G.join())return[];const fw=new Map([[rep.join(),[]]]),bw=new Map([[G.join(),[]]]);let ff=[rep],bf=[G];
 for(let d=0;d<maxd;d++){if(ff.length<=bf.length){const nf=[];for(const s of ff){const sq=fw.get(s.join());for(const m of moves){const t=ap(s,m.p),k=t.join();if(fw.has(k))continue;const q=sq.concat(m.n);fw.set(k,q);if(bw.has(k))return q.concat(bw.get(k));nf.push(t)}}ff=nf}
  else{const nb=[];for(const s of bf){const sq=bw.get(s.join());for(let i=0;i<moves.length;i++){const t=ap(s,pinv[i].i),k=t.join();if(bw.has(k))continue;const q=[moves[i].n].concat(sq);bw.set(k,q);if(fw.has(k))return fw.get(k).concat(q);nb.push(t)}}bf=nb}}
 return null}
const out=[];let t0=Date.now();
for(const [k,s] of cls){let a=null;for(const set of [['R','U','L'],['R','U','L','F'],['R','U','L','F','D']]){a=search(s,mv(set),13);if(a)break}out.push({s,alg:a?a.join(' '):null})}
console.log('tanpa alg',out.filter(o=>o.alg===null).length,'panjang',out.map(o=>o.alg===null?'x':o.alg.split(' ').filter(Boolean).length).join(','),(Date.now()-t0)+'ms');
require('fs').writeFileSync(require('path').join(__dirname,'data/cmll_raw.json'),JSON.stringify(out));
