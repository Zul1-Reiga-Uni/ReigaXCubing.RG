/* Memuat js/solver.js sebagai model kubus untuk skrip alat (node). */
const fs=require('fs'),path=require('path');
const src=fs.readFileSync(path.join(__dirname,'..','js/solver.js'),'utf8');
module.exports=new Function(src+';return {SL,IX,CI,CU,tok,TP,seqP,ap,ID,MD,QP,toCub,CORN,prep,solve}')();
