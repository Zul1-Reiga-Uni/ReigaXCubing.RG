/* Menambahkan gambar kasus, tahap, dan ikon bab baru ke seni/gambar/index.html dan DAFTAR-GAMBAR.txt (aman dijalankan ulang). */
const fs=require('fs'),path=require('path'),g=path.join(__dirname,'..','seni/gambar');
const K=new Function(fs.readFileSync(path.join(__dirname,'..','js/kasus.js'),'utf8')+';return KASUS')();
let html=fs.readFileSync(path.join(g,'index.html'),'utf8');html=html.replace(/<!--BARU-->[\s\S]*$/,'');
const fig=(f,t)=>`<figure><img src="${f}" alt="${t}" loading="lazy"><figcaption><b>${t}</b><br>${f}</figcaption></figure>`;
const sec=(t,items)=>`<h2>${t} (${items.length})</h2><div class="g">${items.map(([f,n])=>fig(f,n)).join('')}</div>`;
const names={cross:'Cross',f2l:'F2L',oll:'OLL',pll:'PLL',cmll:'CMLL'};let add='<!--BARU-->',txt='\n\n=== Gambar kasus dan tahap metode (dibuat oleh alat/bangun-kasus.js) ===\n';
const tahap=Object.entries(K.tahap).map(([k,f])=>['../gambar/seni_'.slice(0,0)+f.replace(/^/,''),'tahap '+k]);
add+=sec('Tahap metode',Object.entries(K.tahap).map(([k,f])=>[f,k]));
txt+='\nseni/gambar/tahap/*.svg dan .png  : bentuk kubus setelah tiap tahap (cross, lapisan pertama, F2L, OLL, blok Roux, dst)\n';
for(const k of Object.keys(names)){add+=sec('Kasus '+names[k],K[k].map(c=>[c.img.replace('.svg','.png'),(c.nm||names[k]+' '+c.no)]));txt+=`seni/gambar/kasus/${k}/*.svg dan .png : ${K[k].length} kasus ${names[k]}\n`}
const iv=['kubus','metode','roux','roux-blok','cmll','lse','zz','petrus'];add+=sec('Ikon bab baru',iv.map(i=>[`ikon/ikon_${i}.png`,i]));txt+='seni/gambar/ikon/ikon_{kubus,metode,roux,roux-blok,cmll,lse,zz,petrus}.svg dan .png : ikon bab baru\n';
fs.writeFileSync(path.join(g,'index.html'),html+add);
let d=fs.readFileSync(path.join(g,'DAFTAR-GAMBAR.txt'),'utf8');d=d.replace(/\n\n=== Gambar kasus dan tahap metode[\s\S]*$/,'');fs.writeFileSync(path.join(g,'DAFTAR-GAMBAR.txt'),d+txt);
console.log('galeri diperbarui');
