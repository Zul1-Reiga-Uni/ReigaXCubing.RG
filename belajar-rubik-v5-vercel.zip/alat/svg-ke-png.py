"""Ubah semua SVG ikon (dan opsional gambar kasus) menjadi PNG transparan 512x512 memakai Playwright.
Pemakaian: python3 alat/svg-ke-png.py [folder_svg ...]   (bawaan: seni/gambar/ikon)"""
import asyncio,os,sys
from playwright.async_api import async_playwright
root=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..')
dirs=sys.argv[1:] or ['seni/gambar/ikon']
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':512,'height':512})
        for d in dirs:
            full=os.path.join(root,d)
            for f in sorted(os.listdir(full)):
                if not f.endswith('.svg'):continue
                svg=open(os.path.join(full,f)).read()
                await pg.set_content('<body style="margin:0;background:transparent">'+svg+'</body>')
                await pg.screenshot(path=os.path.join(full,f[:-4]+'.png'),omit_background=True,clip={'x':0,'y':0,'width':512,'height':512})
        await b.close()
asyncio.run(main())
