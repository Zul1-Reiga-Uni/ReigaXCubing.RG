/* Membuat ikon SVG untuk semua bab (seni/gambar/ikon/ikon_<id>.svg) dari pola IV di seni/seni.js.
   Lalu ubah ke PNG: python3 alat/svg-ke-png.py */
const fs=require('fs'),path=require('path'),root=path.join(__dirname,'..');
const src=fs.readFileSync(path.join(root,'seni/seni.js'),'utf8');
const {IV,icoSvg}=new Function('MD','tok','fm',src.replace(/^const ART_DIR.*$/m,'')+';return {IV,icoSvg}')({},()=>null,x=>x);
let n=0;for(const id of Object.keys(IV)){const f=path.join(root,`seni/gambar/ikon/ikon_${id}.svg`);fs.writeFileSync(f,icoSvg(id,512));n++}
console.log('ikon SVG:',n);
