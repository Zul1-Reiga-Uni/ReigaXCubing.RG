/* Pembuat gambar & data kasus. Jalankan: node alat/bangun-kasus.js  (dari folder proyek)
   Membaca js/solver.js sebagai model kubus, lalu menulis seni/gambar/kasus/*, seni/gambar/tahap/* dan js/kasus.js */
const fs=require('fs'),path=require('path'),root=path.join(__dirname,'..');
const H=new Function(fs.readFileSync(path.join(root,'js/solver.js'),'utf8')+';return {SL,IX,CI,tok,TP,seqP,ap,ID,toCub,CORN}')();
const {SL,IX,CI,tok,TP,seqP,ap,ID,toCub}=H;
const HOME=SL.map(s=>'YRGWOB'['URFDLB'.indexOf(s.f)]);
const CF={Y:'#ffd500',W:'#f4f4f4',R:'#c8102e',O:'#ff5800',B:'#0051ba',G:'#009a44',N:'#a3adbf'};
const OLLA=require('./data/algs_oll.js'),PLLA=require('./data/algs_pll.js'),F2L=JSON.parse(fs.readFileSync(path.join(__dirname,'data/f2l_raw.json'))),CML=JSON.parse(fs.readFileSync(path.join(__dirname,'data/cmll_raw.json')));
const inv=a=>a.trim().split(/\s+/).reverse().map(t=>{const q=tok(t);return q.n+(q.k===2?'2':q.k>0?"'":'')}).join(' ');
const fixRot=a=>{const t=a.trim().split(/\s+/);return /^[xyz]/.test(t[0])?a+' '+(t[0].endsWith("'")?t[0][0]:t[0]+"'"):a};
const caseState=a=>ap(HOME,seqP(inv(fixRot(a))));
const FN={U:'Atas',D:'Bawah',R:'Kanan',L:'Kiri',F:'Depan',B:'Belakang'},CN={W:'putih',Y:'kuning',R:'merah',O:'oranye',B:'biru',G:'hijau'};
const faceOf=n=>n[1]===1?'U':n[1]===-1?'D':n[0]===1?'R':n[0]===-1?'L':n[2]===1?'F':'B';
const cubName=c=>(c[1]===1?'U':c[1]===-1?'D':'')+(c[2]===1?'F':c[2]===-1?'B':'')+(c[0]===1?'R':c[0]===-1?'L':'');
const out=(rel,txt)=>{const f=path.join(root,rel);fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,txt)};
const SV=(g,bg)=>`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="512" height="512">${g}</svg>`;
/* ---------- tampilan isometrik ---------- */
const TV=[(v)=>v,(v)=>[-v[0],-v[1],v[2]]];
const FACES3=[{p0:[14,32],u:[12,6],v:[0,14],f:(c,r)=>[[c-1,1-r,1],[0,0,1]]},{p0:[50,50],u:[12,-6],v:[0,14],f:(c,r)=>[[1,1-r,1-c],[1,0,0]]},{p0:[50,14],u:[12,6],v:[-12,6],f:(c,r)=>[[c-1,1,r-1],[0,1,0]]}];
function iso(colFn,view,hi){let g='';for(const F of FACES3)for(let r=0;r<3;r++)for(let c=0;c<3;c++){const[cc,nn]=F.f(c,r),a=TV[view](cc),b=TV[view](nn),j=IX[a.join()+'|'+b.join()];
 const pt=(x,y)=>[F.p0[0]+F.u[0]*x+F.v[0]*y,F.p0[1]+F.u[1]*x+F.v[1]*y].map(n=>n.toFixed(1)).join(',');
 const col=colFn(j),h=hi&&hi(j);g+=`<polygon points="${pt(c,r)} ${pt(c+1,r)} ${pt(c+1,r+1)} ${pt(c,r+1)}" fill="${CF[col]||CF.N}"${h===0?' fill-opacity=".45"':''} stroke="#0b0b0b" stroke-width="${h===1?2.4:1.3}" stroke-linejoin="round"/>`}
 return SV(g)}
/* ---------- tampilan atas (OLL/PLL/CMLL) ---------- */
const cellXY=(x,z)=>[20+(x+1)*20+10,20+(z+1)*20+10];
function topView(colFn,arrows){let g='';const sl=(x,y,z,n)=>IX[[x,y,z].join()+'|'+n.join()];
 const rect=(x,y,w,h,col)=>`<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="2" fill="${CF[col]||CF.N}" stroke="#0b0b0b" stroke-width="1.4"/>`;
 for(let r=0;r<3;r++)for(let c=0;c<3;c++)g+=rect(20+c*20+1,20+r*20+1,18,18,colFn(sl(c-1,1,r-1,[0,1,0])));
 for(let i=0;i<3;i++){g+=rect(20+i*20+1,10,18,7,colFn(sl(i-1,1,-1,[0,0,-1])))+rect(20+i*20+1,83,18,7,colFn(sl(i-1,1,1,[0,0,1])))+rect(10,20+i*20+1,7,18,colFn(sl(-1,1,i-1,[-1,0,0])))+rect(83,20+i*20+1,7,18,colFn(sl(1,1,i-1,[1,0,0])))}
 for(const [a,b,two] of arrows||[]){const[x1,y1]=cellXY(...a),[x2,y2]=cellXY(...b),dx=x2-x1,dy=y2-y1,L=Math.hypot(dx,dy),ux=dx/L,uy=dy/L,s=10,sx=x1+ux*3,sy=y1+uy*3,ex=x2-ux*3,ey=y2-uy*3;
  const head=(x,y,vx,vy)=>`<polygon points="${(x+vx*5).toFixed(1)},${(y+vy*5).toFixed(1)} ${(x-vx*2-vy*3.2).toFixed(1)},${(y-vy*2+vx*3.2).toFixed(1)} ${(x-vx*2+vy*3.2).toFixed(1)},${(y-vy*2-vx*3.2).toFixed(1)}" fill="#0b0b0b" stroke="#fff" stroke-width=".8"/>`;
  g+=`<line x1="${sx.toFixed(1)}" y1="${sy.toFixed(1)}" x2="${ex.toFixed(1)}" y2="${ey.toFixed(1)}" stroke="#fff" stroke-width="4.6" stroke-linecap="round"/><line x1="${sx.toFixed(1)}" y1="${sy.toFixed(1)}" x2="${ex.toFixed(1)}" y2="${ey.toFixed(1)}" stroke="#0b0b0b" stroke-width="2.2" stroke-linecap="round"/>`+head(ex,ey,ux,uy)+(two?head(sx,sy,-ux,-uy):'')}
 return SV(g)}
/* ---------- OLL ---------- */
const ollCol=s=>j=>{const x=SL[j];return x.c[1]===1&&s[j]===HOME[CI.U]?'Y':'N'};
const ollInfo=s=>{const Y=HOME[CI.U],u=(x,z)=>s[IX[[x,1,z].join()+'|0,1,0']]===Y;const e=[u(0,-1),u(1,0),u(0,1),u(-1,0)],cn=[u(-1,-1),u(1,-1),u(1,1),u(-1,1)],ne=e.filter(Boolean).length,nc=cn.filter(Boolean).length;
 const sh=ne===4?'Salib (semua edge sudah kuning)':ne===0?'Titik (belum ada edge kuning)':ne===2?((e[0]&&e[2])||(e[1]&&e[3])?'Garis':'Siku (L)'):'Edge';return`${sh}. Corner kuning di atas: ${nc}.`};
const OLL=OLLA.map((a,i)=>{const s=caseState(a),no=String(i+1).padStart(2,'0');out(`seni/gambar/kasus/oll/oll-${no}.svg`,topView(ollCol(s)));return{no:i+1,a,h:ollInfo(s),img:`kasus/oll/oll-${no}.svg`}});
/* ---------- PLL ---------- */
const posXZ={};const U_EDGE=[[0,-1],[1,0],[0,1],[-1,0]],U_CORN=[[-1,-1],[1,-1],[1,1],[-1,1]];
function pllInfo(s){const c=toCub(s);const cyc=(arr)=>{const mv=arr.map((k,p)=>k!==p?p:-1).filter(p=>p>=0);return mv};
 const cm=cyc(c.cp),em=cyc(c.ep);const nm=n=>n===0?'tidak berpindah':n===2?'tukar 2':n===3?'putar 3':n===4?'tukar 2 pasang':n+' berpindah';return{c:cm.length,e:em.length,t:`Corner: ${nm(cm.length)}. Edge: ${nm(em.length)}.`,c_:c}}
const cubXZ=(slotList,p)=>{const x=SL[slotList[p][0]].c;return[x[0],x[2]]};
const CORNL=H.CORN;
function pllArrows(c){const ar=[],used=new Set();const EDG=[];
 // posisi corner/edge di lapisan U -> koordinat
 const cxz=p=>{const x=SL[CORNL[p][0]].c;return[x[0],x[2]]};
 c.cp.forEach((k,p)=>{if(SL[CORNL[p][0]].c[1]!==1||k===p||SL[CORNL[k][0]].c[1]!==1)return;const key=[p,k].sort().join(),two=c.cp[k]===p;if(two&&used.has('c'+key))return;used.add('c'+key);ar.push([cxz(p),cxz(k),two])});
 return ar}
/* ---------- gambar ---------- */
const edgeSlots=[];
const PLL=PLLA.map(([nm,a])=>{const s=caseState(a),c=toCub(s);const info=pllInfo(s);
 // panah edge dan corner (hanya posisi di lapisan U)
 const EDGL=require('./edge-list.js')(H);const ex=p=>{const x=SL[EDGL[p][0]].c;return[x[0],x[2]]};const cx=p=>{const x=SL[CORNL[p][0]].c;return[x[0],x[2]]};const ar=[],used=new Set();
 const isU=(L,p)=>SL[L[p][0]].c[1]===1;
 c.cp.forEach((k,p)=>{if(k===p||!isU(CORNL,p)||!isU(CORNL,k))return;const two=c.cp[k]===p,key='c'+[p,k].sort();if(two&&used.has(key))return;used.add(key);ar.push([cx(p),cx(k),two])});
 c.ep.forEach((k,p)=>{if(k===p||!isU(EDGL,p)||!isU(EDGL,k))return;const two=c.ep[k]===p,key='e'+[p,k].sort();if(two&&used.has(key))return;used.add(key);ar.push([ex(p),ex(k),two])});
 out(`seni/gambar/kasus/pll/pll-${nm}.svg`,topView(j=>{const x=SL[j];return x.c[1]===1?s[j]:'N'},ar));return{nm,a,h:info.t,img:`kasus/pll/pll-${nm}.svg`}});
/* ---------- F2L ---------- */
const f2lDesc=s=>{const lab=(c)=>SL.map((x,i)=>x.c.join()===c.join()?i:-1).filter(i=>i>=0);const co=lab([1,-1,1]),ed=lab([1,0,1]);
 const where=l=>{const p=s.indexOf(l);return{c:SL[p].c,n:SL[p].n}};
 const w=where(co.find(l=>HOME[l]==='W')),e=where(ed.find(l=>HOME[l]==='G'));
 const cn=cubName(w.c),en=cubName(e.c),inSlotC=w.c[1]<0,inSlotE=e.c[1]===0;
 const g=inSlotC&&inSlotE?3:inSlotC?1:inSlotE?2:0;
 const t=`Corner di ${inSlotC?'slot (kanan depan)':cn}, putih menghadap ${FN[faceOf(w.n)]}. Edge di ${inSlotE?'slot (kanan depan)':en}, warna hijau menghadap ${FN[faceOf(e.n)]}.`;return{g,t}};
const f2lAll=F2L.filter(o=>o.alg).map(o=>({s:o.s,a:o.alg,...f2lDesc(o.s)}));
f2lAll.sort((a,b)=>a.g-b.g||a.t.localeCompare(b.t));
const GN=['Corner dan edge sama-sama di lapisan atas','Corner di slot, edge di lapisan atas','Edge di slot, corner di lapisan atas','Corner dan edge sama-sama di slot (belum benar)'];
const PAIRL=[...SL.map((x,i)=>x.c.join()==='1,-1,1'||x.c.join()==='1,0,1'?i:-1).filter(i=>i>=0)];
const F2LC=f2lAll.map((o,i)=>{const no=String(i+1).padStart(2,'0');out(`seni/gambar/kasus/f2l/f2l-${no}.svg`,iso(j=>{const l=o.s[j];return l<0?'N':HOME[l]},0,j=>PAIRL.includes(o.s[j])?1:0));return{no:i+1,g:GN[o.g],a:o.a,h:o.t,img:`kasus/f2l/f2l-${no}.svg`}});
/* ---------- CMLL ---------- */
const cmllInfo=s=>{const cn=[[-1,-1],[1,-1],[1,1],[-1,1]].map(([x,z])=>{const j=IX[[x,1,z].join()+'|0,1,0'];return s[j]>=0&&HOME[s[j]]==='Y'});const n=cn.filter(Boolean).length;return`Corner kuning di atas: ${n}.`};
const cmllOrdered=CML.filter(o=>o.alg).sort((a,b)=>a.alg.split(' ').length-b.alg.split(' ').length);
const CMLL=cmllOrdered.map((o,i)=>{const no=String(i+1).padStart(2,'0'),s=o.s,corner=j=>{const x=SL[j];return x.c[1]===1&&Math.abs(x.c[0])===1&&Math.abs(x.c[2])===1&&s[j]>=0?HOME[s[j]]:'N'};
 out(`seni/gambar/kasus/cmll/cmll-${no}.svg`,topView(corner));return{no:i+1,a:o.alg,h:cmllInfo(s),img:`kasus/cmll/cmll-${no}.svg`}}).filter(x=>x.a!=='');

/* ---------- Cross: satu edge (putih-hijau) menuju slot depan-bawah ---------- */
{const E=SL.map((x,i)=>x.c.join()==='0,-1,1'?i:-1).filter(i=>i>=0),lab0=SL.map((_,i)=>i),mkS=a=>a.map(l=>E.includes(l)?l:-1);
 const G=mkS(lab0),moves=[];for(const X of 'URFDLB'){moves.push({n:X,p:seqP(X)},{n:X+'2',p:seqP(X+'2')},{n:X+"'",p:seqP(X+"'")})}
 const seen=new Map([[G.join(),{s:G,a:[]}]]);let fr=[G];
 while(fr.length){const nx=[];for(const s of fr){const cur=seen.get(s.join());for(const m of moves){const t=ap(s,m.p),k=t.join();if(!seen.has(k)){seen.set(k,{s:t,a:[m.n].concat(cur.a)});nx.push(t)}}}fr=nx}
 // seen[s].a adalah urutan balik (dari G ke s lewat gerakan m): untuk s, jalan pulang = invers
 const invm=n=>n.endsWith("'")?n.slice(0,-1):n.endsWith('2')?n:n+"'";
 const items=[...seen.values()].filter(o=>o.a.length).map(o=>({s:o.s,a:o.a.map(invm).join(' ')}));
 items.sort((x,y)=>x.a.split(' ').length-y.a.split(' ').length||x.a.localeCompare(y.a));
 const CROSS=items.map((o,i)=>{const no=String(i+1).padStart(2,'0'),wp=o.s.indexOf(E.find(l=>HOME[l]==='W')),gp=o.s.indexOf(E.find(l=>HOME[l]==='G')),w=SL[wp],g=SL[gp];
  const view=w.c[1]===-1&&g.c[1]===-1?1:0;
  out(`seni/gambar/kasus/cross/cross-${no}.svg`,iso(j=>{const l=o.s[j];if(l>=0)return HOME[l];const x=SL[j];return x.c[0]===0&&x.c[2]===0&&(x.n[1]===-1||x.n[2]===1)?HOME[j]:'N'},view,j=>o.s[j]>=0?1:0));
  return{no:i+1,a:o.a,h:`Edge putih-hijau ada di ${cubName(w.c)}: putih menghadap ${FN[faceOf(w.n)]}, hijau menghadap ${FN[faceOf(g.n)]}.`,img:`kasus/cross/cross-${no}.svg`}});
 var CROSSC=CROSS}
/* ---------- gambar tahap metode ---------- */
const piece=pred=>j=>pred(SL[j].c)?HOME[j]:'N';
const D_EDGES=c=>c[1]===-1&&Math.abs(c[0])+Math.abs(c[2])===1||c[0]===0&&c[1]===-1&&c[2]===0;
const P={
 daisy:j=>{const x=SL[j];if(x.n[1]===1&&x.c[0]===0&&x.c[2]===0)return'Y';if(x.n[1]===1&&Math.abs(x.c[0])+Math.abs(x.c[2])===1)return'W';return'N'},
 cross:piece(D_EDGES),d_layer:piece(c=>c[1]===-1),f2l:piece(c=>c[1]<=0),
 f2l_ycross:j=>{const x=SL[j];if(x.c[1]<=0)return HOME[j];if(x.n[1]===1&&Math.abs(x.c[0])+Math.abs(x.c[2])<=1)return'Y';return'N'},
 f2l_yedges:j=>{const x=SL[j];if(x.c[1]<=0||(Math.abs(x.c[0])+Math.abs(x.c[2])<=1))return HOME[j];return'N'},
 f2l_yedges_c:j=>{const x=SL[j];if(x.c[1]<=0||(Math.abs(x.c[0])+Math.abs(x.c[2])<=1))return HOME[j];return x.n[1]===1?'N':HOME[j]},
 f2l_oll:j=>{const x=SL[j];if(x.c[1]<=0)return HOME[j];return x.n[1]===1?'Y':'N'},
 solved:j=>HOME[j],
 left:piece(c=>c[0]===-1&&c[1]<=0),right:piece(c=>c[0]===1&&c[1]<=0),blocks:piece(c=>Math.abs(c[0])===1&&c[1]<=0),
 cmll:piece(c=>(Math.abs(c[0])===1&&c[1]<=0)||(c[1]===1&&Math.abs(c[0])===1&&Math.abs(c[2])===1)),
 line:piece(c=>c[1]===-1&&c[0]===0&&c[2]!==0||c[0]===0&&c[1]===-1&&c[2]===0),
 b222:piece(c=>c[0]<=0&&c[1]<=0&&c[2]<=0),b223:piece(c=>c[0]<=0&&c[1]<=0),
 ocll:j=>{const x=SL[j];if(x.c[1]<=0)return HOME[j];return x.n[1]===1&&Math.abs(x.c[0])===1&&Math.abs(x.c[2])===1?'Y':'N'}};
const ST=[['cross','z2'],['d_layer','z2'],['f2l','z2'],['daisy','v0'],['f2l_ycross','v0'],['f2l_yedges','v0'],['f2l_yedges_c','v0'],['f2l_oll','v0'],['solved','v0'],['left','z2'],['right','v0'],['blocks','v0'],['cmll','v0'],['line','z2'],['b222','z2'],['b223','z2'],['ocll','v0']];
for(const[k,v]of ST)out(`seni/gambar/tahap/${k}.svg`,iso(P[k],v==='z2'?1:0));
const mapStages={};ST.forEach(([k])=>mapStages[k]=`tahap/${k}.svg`);
out('js/kasus.js',`/* DIBUAT OTOMATIS oleh alat/bangun-kasus.js. Jangan diubah tangan. */\nconst KASUS=${JSON.stringify({cross:CROSSC,f2l:F2LC,oll:OLL,pll:PLL,cmll:CMLL,tahap:mapStages})};\n`);
console.log('CROSS',CROSSC.length,'F2L',F2LC.length,'OLL',OLL.length,'PLL',PLL.length,'CMLL',CMLL.length,'tahap',ST.length);
