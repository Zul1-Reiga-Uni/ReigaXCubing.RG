const H=require('./hz.js'),{SL,IX,CI,tok,TP,seqP,ap,ID}=H;
const lab0=SL.map((_,i)=>i),isLL=i=>SL[i].c[1]===1,mk=a=>a.map(l=>isLL(l)?-1:l),G=mk(lab0);
const P=n=>seqP(n);
const cubSlots=c=>SL.map((s,i)=>s.c.join()===c.join()?i:-1).filter(i=>i>=0);
const CORNER=cubSlots([1,-1,1]),EDGE=cubSlots([1,0,1]),PAIR=[...CORNER,...EDGE];
const mv=(names)=>{const o=[];for(const X of names){o.push({n:X,p:P(X)},{n:X+'2',p:P(X+'2')},{n:X+"'",p:P(X+"'")})}return o};
const keep=s=>{for(let j=0;j<54;j++){if(SL[j].c[1]<=0&&!PAIR.includes(j)&&s[j]!==j)return false}return true};
// BFS state classes with macros preserving other pieces
const mac=[];for(const u of ['U',"U'",'U2'])mac.push([u,P(u)]);
for(const X of ['R','F'])for(const u of ['U',"U'",'U2']){mac.push([`${X} ${u} ${X}'`,P(`${X} ${u} ${X}'`)]);mac.push([`${X}' ${u} ${X}`,P(`${X}' ${u} ${X}`)])}
const seen=new Map([[G.join(),{s:G,d:0}]]);let fr=[G];
while(fr.length){const nx=[];for(const s of fr)for(const [n,p] of mac){const t=ap(s,p);if(!keep(t))continue;const k=t.join();if(!seen.has(k)){seen.set(k,{s:t,d:seen.get(s.join()).d+1});nx.push(t)}}fr=nx}
const UP=[ID,P('U'),P('U2'),P("U'")];
const canon=s=>{let b=null;for(const u of UP){const t=ap(s,u);const k=PAIR.map(l=>t.indexOf(l)).join(',');if(b===null||k<b)b=k}return b};
const cls=new Map();for(const {s,d} of seen.values()){const k=canon(s);if(!cls.has(k)||cls.get(k).d>d)cls.set(k,{s,d})}
console.log('state',seen.size,'kelas',cls.size);
function search(rep,moves,maxd){const inv=m=>({n:m.n.endsWith("'")?m.n.slice(0,-1):m.n.endsWith('2')?m.n:m.n+"'",p:null});
 const fw=new Map([[rep.join(),[]]]),bw=new Map([[G.join(),[]]]);let ff=[rep],bf=[G];
 const pinv=moves.map(m=>({n:m.n,i:moves.find(x=>x.n===(m.n.endsWith("'")?m.n.slice(0,-1):m.n.endsWith('2')?m.n:m.n+"'")).p}));
 if(fw.has(G.join()))return[];
 for(let d=0;d<maxd;d++){const useF=ff.length<=bf.length;
  if(useF){const nf=[];for(const s of ff){const sq=fw.get(s.join());for(let i=0;i<moves.length;i++){const m=moves[i];const t=ap(s,m.p),k=t.join();if(fw.has(k))continue;const q=sq.concat(m.n);fw.set(k,q);if(bw.has(k))return q.concat(bw.get(k));nf.push(t)}}ff=nf}
  else{const nb=[];for(const s of bf){const sq=bw.get(s.join());for(let i=0;i<moves.length;i++){const t=ap(s,pinv[i].i),k=t.join();if(bw.has(k))continue;const q=[moves[i].n].concat(sq);bw.set(k,q);if(fw.has(k))return fw.get(k).concat(q);nb.push(t)}}bf=nb}}
 return null}
const out=[];
for(const [k,{s}] of cls){let a=null;for(const set of [['R','U'],['R','U','F'],['R','U','F','L'],['R','U','F','L','D']]){a=search(s,mv(set),12);if(a)break}
 out.push({s,key:k,alg:a?a.join(' '):null})}
console.log('tanpa alg:',out.filter(o=>!o.alg).length,'panjang:',out.map(o=>o.alg?o.alg.split(' ').length:0).join(','));
require('fs').writeFileSync(require('path').join(__dirname,'data/f2l_raw.json'),JSON.stringify(out.map(o=>({s:o.s,alg:o.alg}))));
