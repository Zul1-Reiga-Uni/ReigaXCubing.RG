const S = require('../lib/store');

/* Hapus akun: wajib kata sandi yang benar, dan ikut aturan kunci yang sama */
module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Metode tidak diizinkan.' });
  try {
    const b = typeof req.body === 'string' ? JSON.parse(req.body) : (req.body || {});
    const n = String(b.n || '').trim().toLowerCase();
    const pw = String(b.pw || '');
    if (!n || !pw) return res.status(400).json({ error: 'Masukkan kata sandi untuk menghapus akun.' });
    const r = await S.attempt(n, pw, S.getIp(req));
    if (r.code !== 200) return res.status(r.code).json({ error: r.error });
    await S.kdel('user:' + n);
    await S.kdel('sec:' + n);
    return res.status(200).json({ ok: true });
  } catch (e) {
    return res.status(500).json({ error: 'Server sedang bermasalah. Coba lagi nanti.' });
  }
};
