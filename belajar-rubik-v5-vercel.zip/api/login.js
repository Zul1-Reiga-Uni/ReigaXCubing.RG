const S = require('../lib/store');

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Metode tidak diizinkan.' });
  try {
    const b = typeof req.body === 'string' ? JSON.parse(req.body) : (req.body || {});
    const n = String(b.n || '').trim().toLowerCase();
    const pw = String(b.pw || '');
    if (!n || !pw) return res.status(400).json({ error: 'Isi nama pengguna dan kata sandi.' });

    const ip = S.getIp(req);
    const r = await S.attempt(n, pw, ip);
    if (r.code !== 200) return res.status(r.code).json({ error: r.error });

    // catat IP dan waktu masuk terakhir
    r.user.lip = ip; r.user.ll = Date.now();
    await S.kset('user:' + n, r.user);
    return res.status(200).json({ ok: true, n });
  } catch (e) {
    return res.status(500).json({ error: 'Server sedang bermasalah. Coba lagi nanti.' });
  }
};
