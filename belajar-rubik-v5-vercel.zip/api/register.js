const S = require('../lib/store');

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Metode tidak diizinkan.' });
  try {
    const b = typeof req.body === 'string' ? JSON.parse(req.body) : (req.body || {});
    const n = String(b.n || '').trim().toLowerCase();
    const pw = String(b.pw || '');
    if (!/^[a-z0-9_]{3,20}$/.test(n)) return res.status(400).json({ error: 'Nama pengguna 3–20 karakter: huruf kecil, angka, atau garis bawah.' });
    if (pw.length < 6 || pw.length > 200) return res.status(400).json({ error: 'Kata sandi minimal 6 karakter.' });
    if (await S.kget('user:' + n)) return res.status(409).json({ error: 'Nama ini sudah dipakai. Coba nama lain atau masuk.' });

    const ip = S.getIp(req), now = Date.now();
    const { s, h } = await S.hashPassword(pw);
    // IP saat daftar disimpan sebagai rip (register IP); lip = IP masuk terakhir
    await S.kset('user:' + n, { s, h, c: now, rip: ip, lip: ip, ll: now });
    return res.status(200).json({ ok: true, n });
  } catch (e) {
    return res.status(500).json({ error: 'Server sedang bermasalah. Coba lagi nanti.' });
  }
};
